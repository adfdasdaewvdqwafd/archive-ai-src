import { useEffect, useReducer, useRef, useState } from 'react';
import { ArrowRight, ChevronRight, CircleAlert, FolderPlus, Layers, LockKeyhole, ShieldCheck, Sparkles, X } from 'lucide-react';
import type { Album, ApplyResult, ArchiveFeedback as Feedback, ArchiveService, FeedbackDetails, Library, Note, Round, Scenario, Settings } from '../../contracts/archive';
import { DEFAULT_ELIGIBILITY, canOfferNextRound, eligible, publicTargets, unfiled } from './domain/rules';
import { generationReadyAt, presentationFinished, type GenerationProgress } from './domain/generation';
import { SCENARIOS, createScenarioSettings } from './fixtures/library';
import { DATA_MODE, createService, generationPresentation, resetGenerationPresentation, scenario as initialScenario, selectDemoScenario, service as initialService, storagePersistent } from './services';
import { MockArchiveService } from './services/mock';
import { USER_SCENARIOS } from './services/scenarios';
import { Cover, Header, Sheet, Toggle, NoticeContext } from './components/ui';
import { Home } from './components/Home';
import { RangePage } from './components/RangePage';
import { Preview } from './components/Preview';
import { NoteList, AdjustSheet, PublicSheet, CreateSheet } from './components/ArchiveSheets';
import { ScenarioConsole } from './components/ScenarioConsole';
import { ArchiveFeedback } from './components/ArchiveFeedback';
import { GenerationPage } from './components/GenerationPage';
import { ResultPage } from './components/ResultPage';

type Page = 'home' | 'range' | 'generating' | 'preview' | 'error' | 'result';
type Modal = { kind: 'settings' } | { kind: 'list'; ids: string[]; title: string } | { kind: 'adjust'; ids: string[] } | { kind: 'public' } | { kind: 'create' } | { kind: 'note'; note: Note } | { kind: 'album'; album: Album } | null;
interface View { page: Page; modal: Modal; tab: 'notes' | 'albums' }
type Action = { type: 'page'; page: Page } | { type: 'modal'; modal: Modal } | { type: 'tab'; tab: View['tab'] };
function reducer(state: View, action: Action): View {
  if (action.type === 'page') return { ...state, page: action.page, modal: null };
  if (action.type === 'modal') return { ...state, modal: action.modal };
  return { ...state, tab: action.tab };
}

export default function App() {
  const [session, setSession] = useState({ scenario: initialScenario, service: initialService, revision: 0, message: '' });
  const [consoleOpen, setConsoleOpen] = useState(true);
  function changeScenario(next: Scenario, reset = false) {
    if (DATA_MODE !== 'mock') return;
    if (!reset && next === session.scenario) { setConsoleOpen(false); return; }
    const nextService = next === session.scenario ? session.service : createService(next);
    if (reset) { resetGenerationPresentation(next); if (nextService instanceof MockArchiveService) nextService.reset(); }
    selectDemoScenario(next);
    const url = new URL(location.href);
    url.searchParams.delete('demo'); url.searchParams.set('scenario', next); url.hash = '/home';
    history.replaceState(null, '', url);
    const label = USER_SCENARIOS.find(item => item.id === next)?.label ?? SCENARIOS.find(item => item.id === next)?.name;
    setConsoleOpen(false);
    setSession(previous => ({ scenario: next, service: nextService, revision: previous.revision + 1, message: reset ? '当前情景已重置' : `已切换至${label}` }));
  }
  return <ArchiveApp key={`${session.scenario}:${session.revision}`} scenario={session.scenario} service={session.service} initialMessage={session.message} changeScenario={changeScenario} consoleOpen={consoleOpen} setConsoleOpen={setConsoleOpen}/>;
}

function ArchiveApp({ scenario, service, initialMessage, changeScenario, consoleOpen, setConsoleOpen }: {
  scenario: Scenario; service: ArchiveService; initialMessage: string;
  changeScenario: (scenario: Scenario, reset?: boolean) => void;
  consoleOpen: boolean; setConsoleOpen: (open: boolean) => void;
}) {
  const [view, dispatch] = useReducer(reducer, { page: 'home', modal: null, tab: 'notes' });
  const [library, setLibrary] = useState<Library | null>(null);
  const [settings, setSettings] = useState<Settings>({ noteIds: [], allowNew: true, rangeLabel: '全部' });
  const [rangeDays, setRangeDays] = useState<number | null>(null);
  const [round, setRound] = useState<Round | null>(null);
  const [presentation, setPresentation] = useState<GenerationProgress | null>(null);
  const [result, setResult] = useState<ApplyResult | null>(null);
  const [reminder, setReminder] = useState(false);
  const [selection, setSelection] = useState<string[]>([]);
  const [selecting, setSelecting] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(initialMessage);
  const [initialError, setInitialError] = useState('');
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [ratingOpen, setRatingOpen] = useState(false);
  const lock = useRef(false);
  const initialized = useRef(false);
  const appScroll = useRef<HTMLDivElement>(null);
  const showDemo = DATA_MODE === 'mock' && new URLSearchParams(location.search).get('demo') === '1';

  function changeDemo(next: Scenario, reset = false) {
    if (lock.current || view.page === 'generating' || (!library && !initialError)) return;
    try { changeScenario(next, reset); }
    catch (e) { setMessage(e instanceof Error ? e.message : '情景切换失败，请重试。'); }
  }

  function navigate(page: Page, currentRound = round, replace = false) {
    dispatch({ type: 'page', page });
    const taskPart = currentRound && ['preview', 'generating', 'error'].includes(page) ? `?task=${encodeURIComponent(currentRound.taskId)}&round=${encodeURIComponent(currentRound.id)}` : '';
    history[replace ? 'replaceState' : 'pushState'](null, '', `#/${page}${taskPart}`);
  }
  const modal = (value: Modal) => dispatch({ type: 'modal', modal: value });
  function track(name: string, data?: Record<string, unknown>, currentRound = round) {
    void service.track({ name, taskId: currentRound?.taskId, roundId: currentRound?.id, data }).catch(() => {});
  }
  async function perform(work: () => Promise<void>) {
    if (lock.current) return false;
    lock.current = true; setBusy(true);
    try { await work(); return true; } catch (e) { setMessage(e instanceof Error ? e.message : '操作暂时未完成，请稍后再试。'); return false; }
    finally { lock.current = false; setBusy(false); }
  }
  useEffect(() => {
    let alive = true;
    async function boot() {
      try {
        const data = await service.getLibrary(); if (!alive) return;
        setLibrary(data); setSettings(DATA_MODE === 'mock' ? createScenarioSettings(scenario, data) : { noteIds: unfiled(data).map(n => n.id), allowNew: true, rangeLabel: '全部' });
        if (!initialized.current) {
          initialized.current = true;
          const qualified = eligible(data, Date.now(), DEFAULT_ELIGIBILITY);
          setReminder(qualified && !data.profile.reminderSeen);
          track('eligibility', { qualified }); track('entry_exposure', { source: 'persistent' });
          if (qualified && !data.profile.reminderSeen) { track('entry_exposure', { source: 'reminder' }); void service.markReminderSeen().catch(() => {}); }
        }
        await restoreRoute(data);
      } catch (e) { if (alive) setInitialError(e instanceof Error ? e.message : '加载失败'); }
    }
    async function restoreRoute(loadedLibrary?: Library) {
      const [path, query = ''] = location.hash.replace(/^#\//, '').split('?');
      const params = new URLSearchParams(query);
      const taskId = params.get('task'); const roundId = params.get('round');
      if (taskId && roundId && ['preview', 'generating', 'error'].includes(path)) {
        try {
          const restored = await service.getRound(taskId, roundId); if (!alive) return;
          if (['generating', 'preview', 'error'].includes(restored.status)) {
            const currentLibrary = loadedLibrary ?? await service.getLibrary(); if (!alive) return;
            const waiting = generationPresentation(scenario, restored, currentLibrary, restored.status === 'generating');
            setPresentation(waiting);
            setRound(restored); setSettings({ noteIds: restored.noteIds, allowNew: restored.allowNew, rangeLabel: '已恢复范围' });
            dispatch({ type: 'page', page: restored.status === 'error' ? 'error' : restored.status === 'generating' || (waiting && !presentationFinished(waiting)) ? 'generating' : 'preview' }); return;
          }
        } catch (e) { if (alive) setMessage(e instanceof Error ? e.message : '无法恢复任务'); }
      }
      if (alive) { dispatch({ type: 'page', page: 'home' }); history.replaceState(null, '', '#/home'); }
    }
    void boot();
    void service.getFeedback().then(saved => { if (alive) setFeedback(saved); }).catch(() => {});
    const onHash = () => { if (!lock.current) void restoreRoute(); };
    window.addEventListener('hashchange', onHash);
    return () => { alive = false; window.removeEventListener('hashchange', onHash); };
  }, []);
  useEffect(() => { appScroll.current?.scrollTo(0, 0); }, [view.page]);
  useEffect(() => { if (view.page !== 'home' || view.modal) setConsoleOpen(false); }, [view.page, view.modal]);
  useEffect(() => {
    if (library && !eligible(library, Date.now(), DEFAULT_ELIGIBILITY)) setReminder(false);
  }, [library]);
  useEffect(() => {
    if (!message) return;
    const timer = setTimeout(() => setMessage(''), 4000); return () => clearTimeout(timer);
  }, [message]);
  useEffect(() => {
    if (view.page !== 'generating' || !round) return;
    let active = true; let timer: ReturnType<typeof setTimeout>; let ready: Round | null = null;
    const poll = async () => {
      try {
        const current = ready ?? await service.getRound(round.taskId, round.id); if (!active) return;
        if (current.status === 'preview') {
          ready = current; setRound(current);
          if (presentation && !presentationFinished(presentation)) {
            timer = setTimeout(poll, Math.min(200, Math.max(1, generationReadyAt(presentation) - Date.now())));
          } else { navigate('preview', current, true); track('preview', { selectedCount: current.noteIds.length }, current); }
        }
        else if (current.status === 'error') { setRound(current); navigate('error', current, true); track('generation_failed', undefined, current); }
        else if (current.status === 'cancelled') navigate('home', current, true);
        else { setRound(current); timer = setTimeout(poll, 600); }
      } catch (e) { if (active) { navigate('error', round, true); setMessage(e instanceof Error ? e.message : '连接异常'); } }
    };
    timer = setTimeout(poll, 400); return () => { active = false; clearTimeout(timer); };
  }, [view.page, round?.taskId, round?.id, presentation?.startedAt]);

  function openSettings() {
    setReminder(false); track('entry_click');
    if (library) {
      const valid = new Set(unfiled(library).map(n => n.id));
      setSettings(s => ({ ...s, noteIds: s.noteIds.filter(id => valid.has(id)) }));
    }
    modal({ kind: 'settings' });
  }
  function begin() { void perform(async () => {
    if (!library) return;
    const created = await service.startTask(settings); setRound(created); setSelection([]); setSelecting(false);
    setPresentation(generationPresentation(scenario, created, library));
    track('generation_start', { selectedCount: settings.noteIds.length, rangeLabel: settings.rangeLabel }, created);
    navigate('generating', created);
  }); }
  function returnSettings() { setSelecting(false); setSelection([]); navigate('home'); modal({ kind: 'settings' }); }
  function cancelGeneration() { void perform(async () => { if (!round) return; await service.cancelRound(round.taskId, round.id); setPresentation(null); track('generation_cancel'); returnSettings(); }); }
  function toggleSelect(id: string) { setSelection(ids => ids.includes(id) ? ids.filter(x => x !== id) : [...ids, id]); }
  function apply(confirmedPublicAlbumIds: string[] = []) { void perform(async () => {
    if (!round) return;
    const applied = await service.applyRound(round.taskId, round.id, { idempotencyKey: `${round.taskId}:${round.id}:apply`, confirmedPublicAlbumIds });
    const updatedLibrary = await service.getLibrary();
    setRound({ ...round, status: 'applied' }); setResult(applied); setReminder(false); setLibrary(updatedLibrary);
    track('apply_result', { actualArchivedCount: applied.archivedCount, unclassifiedCount: applied.unclassifiedCount });
    navigate('result');
  }); }
  function continueRound() { void perform(async () => {
    if (!round || !result || !library || !canOfferNextRound(round, result, library)) return;
    const next = await service.nextRound(round.taskId, round.id);
    setPresentation(generationPresentation(scenario, next, library));
    setSettings({ noteIds: next.noteIds, allowNew: next.allowNew, rangeLabel: '上一轮未归档笔记' }); setRangeDays(null);
    setRound(next); setResult(null); setSelection([]); setSelecting(false);
    track('continue_round', { previousRound: round.number, remainingCount: next.noteIds.length }, next);
    navigate('generating', next);
  }); }
  function confirm() { if (round && publicTargets(round).length) modal({ kind: 'public' }); else apply(); }
  function finish(tab: View['tab']) {
    const finishedTaskId = round?.taskId;
    dispatch({ type: 'tab', tab }); navigate('home'); setRound(null); setResult(null); setPresentation(null);
    if (library) setSettings({ noteIds: unfiled(library).map(n => n.id), allowNew: true, rangeLabel: '全部' });
    setRangeDays(null);
    if (finishedTaskId) void perform(async () => {
      const offered = await service.offerFeedback(finishedTaskId);
      if (offered) {
        setFeedback(offered); setRatingOpen(true);
        void service.track({ name: 'feedback_offer', taskId: offered.taskId }).catch(() => {});
      }
    });
  }
  function rateFeedback(rating: number) { void perform(async () => {
    const saved = await service.rateFeedback(rating); setFeedback(saved); setRatingOpen(false);
    void service.track({ name: 'feedback_rating', taskId: saved.taskId, data: { rating: saved.rating } }).catch(() => {});
  }); }
  function submitFeedback(details: FeedbackDetails) { return perform(async () => {
    const saved = await service.submitFeedback(details); setFeedback(saved); setMessage('感谢反馈，已保存你的建议。');
    void service.track({ name: 'feedback_details', taskId: saved.taskId, data: { reasons: saved.reasons, commentLength: saved.comment.length } }).catch(() => {});
  }); }
  const selectedNotes = library?.notes.filter(n => settings.noteIds.includes(n.id)) ?? [];
  const invalidReason = !settings.noteIds.length ? '请至少选择1篇笔记' : !settings.allowNew && !library?.albums.length ? '你还没有专辑，开启新建后才能归档' : '';

  if (showDemo) return <main className="demo-page"><div className="demo-brand"><Sparkles size={28}/><span>收藏归档助手</span></div><h1>每一条分支，都可以亲手试试。</h1><p>独立演示环境。各场景的数据分别保存，重置仅影响当前场景。</p><div className="demo-grid">{SCENARIOS.map(item => <a key={item.id} href={`?scenario=${item.id}#/home`}><span>{item.name}<ArrowRight size={20}/></span><p>{item.description}</p></a>)}</div><a className="demo-back" href="?scenario=main#/home">返回应用<ArrowRight size={17}/></a></main>;
  return <NoticeContext.Provider value={{ message, dismiss: () => setMessage('') }}><div className={`desktop-layout${DATA_MODE === 'mock' ? ' with-scenario-console' : ''}`}><div className="desktop-caption"><span className="brand-dot"/>收藏归档助手<span>把喜欢的，好好收起来。</span></div><div className="app-stage">{DATA_MODE === 'mock' && <ScenarioConsole scenario={scenario} library={library} disabled={busy || view.page === 'generating' || (!library && !initialError)} generating={view.page === 'generating'} persistent={storagePersistent} change={changeDemo} open={consoleOpen} setOpen={setConsoleOpen} launcherVisible={view.page === 'home' && !view.modal && !ratingOpen}/>}<main className="app-shell" ref={appScroll}>{!library ? <div className="loading-page"><Sparkles className="loading-spin" size={36}/><h2>{initialError || '正在打开你的收藏…'}</h2>{initialError && <button className="primary" onClick={() => location.reload()}>重新加载</button>}</div> : <>
    {view.page === 'home' && <Home library={library} tab={view.tab} setTab={tab => dispatch({ type: 'tab', tab })} showReminder={reminder} dismiss={() => { setReminder(false); track('reminder_dismiss'); }} start={openSettings} openNote={note => modal({ kind: 'note', note })} createAlbum={() => modal({ kind: 'create' })} openAlbum={album => modal({ kind: 'album', album })}/>}
    {view.page === 'range' && <RangePage notes={unfiled(library)} selectedIds={settings.noteIds} initialDays={rangeDays} initialLabel={settings.rangeLabel} back={returnSettings} done={(ids, days, label) => { setSettings(s => ({ ...s, noteIds: ids, rangeLabel: label })); setRangeDays(days); returnSettings(); }}/ >}
    {view.page === 'generating' && round && <GenerationPage round={round} library={library} presentation={presentation} busy={busy} cancel={cancelGeneration}/>}
    {view.page === 'preview' && round && <Preview round={round} library={library} selection={selection} selecting={selecting} busy={busy} back={returnSettings} setSelecting={v => { setSelecting(v); setSelection([]); }} toggleSelect={toggleSelect} openNote={note => modal({ kind: 'note', note })} openAll={(ids, title) => modal({ kind: 'list', ids, title })} adjust={ids => modal({ kind: 'adjust', ids })} confirm={confirm}/>}
    {view.page === 'error' && <div className="error-page"><Header title="AI归类" back={() => finish('notes')}/><div className="error-center"><CircleAlert size={48} strokeWidth={1.3}/><h2>暂时没能生成建议</h2><p>连接暂时异常，请稍后从设置继续。</p><div className="saved-settings"><p>已保留本次选择与设置</p><div>已选{settings.noteIds.length}篇</div><div>范围<span>{settings.rangeLabel}</span></div><div>允许新建专辑<span>{settings.allowNew ? '已开启' : '已关闭'}</span></div></div><div className="group-covers">{selectedNotes.slice(0, 3).map(n => <div className="mini-note" key={n.id}><Cover note={n}/><p>{n.title}</p></div>)}</div><p className="no-write">未创建专辑，也未改动收藏。</p></div><footer className="sticky-footer"><button className="primary full" onClick={returnSettings}>返回设置</button><button className="plain full" onClick={() => finish('notes')}>退出</button></footer></div>}
    {view.page === 'result' && result && <ResultPage result={result} offerNext={!!round && canOfferNextRound(round, result, library)} hasSkipped={!!round?.skippedIds.length} busy={busy} continueRound={continueRound} finish={finish}/>}
    {view.modal?.kind === 'settings' && <Sheet title="AI归类" close={() => modal(null)} className="settings-sheet"><p className="sheet-subtitle">先生成建议，确认后再归档。</p><button className="settings-selection" onClick={() => navigate('range')}><div className="settings-selection-head"><div><strong><Layers size={17}/>未归档{unfiled(library).length}篇</strong><span>{settings.rangeLabel}已选 · {settings.noteIds.length}篇</span></div><span>调整范围<ChevronRight size={14}/></span></div><div className="group-covers">{selectedNotes.slice(0, 3).map(n => <div className="mini-note" key={n.id}><Cover note={n}/><p>{n.title}</p></div>)}</div></button><div className="allow-new"><FolderPlus size={20}/><div><strong>允许新建专辑</strong><p className={invalidReason && settings.noteIds.length ? 'field-error' : ''}>{invalidReason && settings.noteIds.length ? invalidReason : '相似笔记满4篇可新建，每轮最多5个。'}</p></div><Toggle checked={settings.allowNew} label="允许新建专辑" onChange={() => setSettings(s => ({ ...s, allowNew: !s.allowNew }))}/></div><div className="settings-assurances"><span><ShieldCheck size={15}/>仅处理未归档笔记</span><span><LockKeyhole size={14}/>新专辑默认私密</span></div><button className="primary full" disabled={!!invalidReason || busy} onClick={begin}>{busy ? '正在开始…' : `开始归类（${settings.noteIds.length}篇）`}</button><p className="footer-hint">{invalidReason || '仅处理未归档笔记。'}</p></Sheet>}
    {view.modal?.kind === 'list' && <NoteList title={view.modal.title} notes={library.notes.filter(n => view.modal?.kind === 'list' && view.modal.ids.includes(n.id))} close={() => modal(null)} done={ids => modal({ kind: 'adjust', ids })}/>}
    {view.modal?.kind === 'adjust' && round && <AdjustSheet ids={view.modal.ids} round={round} library={library} busy={busy} close={() => modal(null)} done={destination => { const ids = view.modal?.kind === 'adjust' ? view.modal.ids : []; void perform(async () => { const updated = await service.adjustRound(round.taskId, round.id, ids, destination); setRound(updated); setSelection([]); setSelecting(false); track('correction', { count: ids.length, destination }); modal(null); }); }}/ >}
    {view.modal?.kind === 'public' && round && <PublicSheet round={round} library={library} busy={busy} close={() => modal(null)} done={() => apply(publicTargets(round).map(g => g.id))}/>}
    {view.modal?.kind === 'create' && <CreateSheet busy={busy} close={() => modal(null)} done={name => { void perform(async () => { await service.createAlbum(name); setLibrary(await service.getLibrary()); modal(null); dispatch({ type: 'tab', tab: 'albums' }); }); }}/ >}
    {view.modal?.kind === 'album' && <Sheet title={view.modal.album.name} close={() => modal(null)}><p className="sheet-subtitle">{view.modal.album.visibility === 'private' ? '私密专辑' : '公开专辑'} · {library.notes.filter(n => view.modal?.kind === 'album' && n.albumIds.includes(view.modal.album.id)).length}篇</p><div className="sheet-list-grid">{library.notes.filter(n => view.modal?.kind === 'album' && n.albumIds.includes(view.modal.album.id)).map(n => <button className="mini-note" key={n.id} onClick={() => modal({ kind: 'note', note: n })}><Cover note={n}/><p>{n.title}</p></button>)}</div></Sheet>}
    {view.modal?.kind === 'note' && <Sheet title="收藏的笔记" close={() => modal(null)} className="note-detail"><Cover note={view.modal.note}/><h3>{view.modal.note.title}</h3><p>{view.modal.note.author} · 收藏于 {new Date(view.modal.note.collectedAt).toLocaleDateString('zh-CN')}</p>{!view.modal.note.accessible && <p>原笔记暂不可访问，保留可见标题与历史封面。</p>}</Sheet>}
  </>}{message && !view.modal && <div className="toast" role="alert">{message}<button aria-label="关闭提示" onClick={() => setMessage('')}><X size={14}/></button></div>}</main>{feedback && <ArchiveFeedback key={feedback.taskId} feedback={feedback} ratingOpen={ratingOpen} visible={view.page === 'home' && !view.modal && !consoleOpen} busy={busy} dismissRating={() => { setRatingOpen(false); void service.track({ name: 'feedback_dismiss', taskId: feedback.taskId }).catch(() => {}); }} rate={rateFeedback} submit={submitFeedback}/>}</div>{DATA_MODE === 'mock' && <div className="desktop-foot"><a href="?demo=1">更多演示场景<ArrowRight size={12}/></a></div>}</div></NoticeContext.Provider>;
}

