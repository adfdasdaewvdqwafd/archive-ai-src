import type { ApplyRequest, ApplyResult, ArchiveEvent, ArchiveFeedback, ArchiveService, ArchiveTask, FeedbackDetails, Library, Scenario, Settings } from '../../../contracts/archive';
import { buildRound, moveNotes, publicTargets } from '../domain/rules';
import { createLibrary } from '../fixtures/library';
import { normalizeFeedback, validateRating } from '../domain/feedback';

export interface StorageLike { getItem(key: string): string | null; setItem(key: string, value: string): void }
interface Database {
  version: 1; library: Library; tasks: Record<string, ArchiveTask>;
  readyAt: Record<string, number>; results: Record<string, ApplyResult>; events: ArchiveEvent[];
  writeFailures?: Record<string, { noteId: string; reason: string }[]>;
  feedback?: ArchiveFeedback;
}
const clone = <T,>(value: T): T => structuredClone(value);
export class MockArchiveService implements ArchiveService {
  private db: Database;
  private key: string;
  constructor(private storage: StorageLike, private scenario: Scenario = 'main', private delay = 1500) {
    this.key = `archive-demo-uploaded-v2:${scenario}`;
    let saved: Database | null = null;
    try { saved = JSON.parse(storage.getItem(this.key) || 'null'); } catch { /* reset corrupt demo data */ }
    this.db = saved?.version === 1 && saved.library && saved.tasks && saved.results && saved.readyAt && Array.isArray(saved.events) ? saved : this.fresh();
    this.persist();
  }
  private fresh(): Database { return { version: 1, library: createLibrary(this.scenario), tasks: {}, readyAt: {}, results: {}, events: [] }; }
  private persist() { this.storage.setItem(this.key, JSON.stringify(this.db)); }
  reset() { this.db = this.fresh(); this.persist(); }
  private get(taskId: string, roundId: string) {
    const task = this.db.tasks[taskId]; const round = task?.rounds.find(r => r.id === roundId);
    if (!task || !round) throw new Error('任务不存在，请返回收藏页重新选择。');
    return { task, round };
  }
  async getLibrary() { return clone(this.db.library); }
  async getFeedback() { return clone(this.db.feedback ?? null); }
  async offerFeedback(taskId: string) {
    if (this.db.feedback) return null;
    if (!this.db.tasks[taskId]) throw new Error('任务不存在，无法评价');
    if (!Object.values(this.db.results).some(result => result.taskId === taskId && result.archivedCount > 0)) return null;
    this.db.feedback = { taskId, offeredAt: Date.now(), rating: null, ratedAt: null, reasons: [], comment: '', submittedAt: null };
    this.persist(); return clone(this.db.feedback);
  }
  async rateFeedback(rating: number) {
    validateRating(rating);
    const feedback = this.db.feedback;
    if (!feedback) throw new Error('请先完成一次AI归类');
    if (feedback.rating !== null) return clone(feedback);
    feedback.rating = rating; feedback.ratedAt = Date.now(); this.persist(); return clone(feedback);
  }
  async submitFeedback(details: FeedbackDetails) {
    const feedback = this.db.feedback;
    if (!feedback || feedback.rating === null) throw new Error('请先为此次归类评分');
    if (feedback.submittedAt !== null) return clone(feedback);
    Object.assign(feedback, normalizeFeedback(details, feedback.rating), { submittedAt: Date.now() });
    this.persist(); return clone(feedback);
  }
  async markReminderSeen() { this.db.library.profile.reminderSeen = true; this.persist(); }
  async createAlbum(name: string) {
    const clean = name.trim(); if (!clean || clean.length > 30) throw new Error('请输入1至30字的专辑名称');
    const existing = this.db.library.albums.find(a => a.name === clean); if (existing) return clone(existing);
    const album = { id: crypto.randomUUID(), name: clean, visibility: 'private' as const };
    this.db.library.albums.push(album); this.db.library.profile.lastMaintainedAt = Date.now(); this.persist(); return clone(album);
  }
  async startTask(settings: Settings) {
    const ids = [...new Set(settings.noteIds)];
    if (!ids.length) throw new Error('请至少选择1篇笔记');
    if (ids.some(id => !this.db.library.notes.some(n => n.id === id && !n.albumIds.length))) throw new Error('部分笔记已归档或不存在，请重新选择范围');
    if (!settings.allowNew && !this.db.library.albums.length) throw new Error('暂无已有专辑，请开启允许新建专辑');
    const id = crypto.randomUUID(); const snapshot = clone({ ...settings, noteIds: ids });
    const round = buildRound(this.db.library, ids, snapshot.allowNew, id, 1);
    this.db.tasks[id] = { id, snapshotIds: ids, settings: snapshot, rounds: [round], skippedIds: [] };
    this.db.readyAt[`${id}/${round.id}`] = Date.now() + this.delay;
    this.persist(); return clone(round);
  }
  async getRound(taskId: string, roundId: string) {
    const { round } = this.get(taskId, roundId);
    if (round.status === 'generating' && Date.now() >= this.db.readyAt[`${taskId}/${roundId}`]) {
      round.status = this.scenario === 'error' ? 'error' : 'preview'; this.persist();
    }
    return clone(round);
  }
  async cancelRound(taskId: string, roundId: string) {
    const { round } = this.get(taskId, roundId);
    if (round.status === 'applied') throw new Error('本轮已经应用');
    round.status = 'cancelled'; this.persist();
  }
  async adjustRound(taskId: string, roundId: string, ids: string[], destination: string | null) {
    const { task, round } = this.get(taskId, roundId);
    const updated = moveNotes(round, ids, destination, this.db.library);
    task.rounds[task.rounds.indexOf(round)] = updated;
    task.skippedIds = [...new Set([...task.skippedIds.filter(id => !ids.includes(id)), ...updated.skippedIds])];
    this.persist(); return clone(updated);
  }
  async applyRound(taskId: string, roundId: string, request: ApplyRequest) {
    const { round } = this.get(taskId, roundId); const resultKey = `${taskId}/${roundId}`;
    if (!request.idempotencyKey) throw new Error('缺少幂等键');
    // The round itself is an idempotency boundary, even across different client keys.
    if (this.db.results[resultKey]) return clone(this.db.results[resultKey]);
    if (round.status !== 'preview') throw new Error('当前轮次不可提交');
    if (publicTargets(round).some(g => !request.confirmedPublicAlbumIds.includes(g.id))) throw new Error('请先确认公开专辑');
    const library = this.db.library; const archivedIds: string[] = [];
    const assigned = round.groups.flatMap(g => g.noteIds);
    const failureId = this.scenario === 'partial' ? assigned[assigned.length - 1] : undefined;
    this.db.writeFailures ??= {};
    this.db.writeFailures[resultKey] = assigned.filter(id => this.scenario === 'zero' || id === failureId).map(noteId => ({ noteId, reason: 'simulated_write_failure' }));
    let newCount = 0;
    for (const group of round.groups) {
      const success = group.noteIds.filter(id => {
        const note = library.notes.find(n => n.id === id);
        return note?.accessible && !note.albumIds.length && this.scenario !== 'zero' && id !== failureId;
      });
      if (!success.length) continue;
      let album = library.albums.find(a => a.id === group.id || a.name === group.name);
      if (!album) {
        if (++newCount > 5) throw new Error('每轮最多新建5个专辑');
        album = { id: crypto.randomUUID(), name: group.name, visibility: 'private' }; library.albums.push(album);
      }
      for (const id of success) { library.notes.find(n => n.id === id)!.albumIds = [album.id]; archivedIds.push(id); }
    }
    if (archivedIds.length) library.profile.lastMaintainedAt = Date.now();
    const result = { taskId, roundId, selectedCount: round.noteIds.length, archivedCount: archivedIds.length, unclassifiedCount: round.noteIds.length - archivedIds.length, archivedIds };
    this.db.results[resultKey] = result; round.status = 'applied'; this.persist(); return clone(result);
  }
  async nextRound(taskId: string, roundId: string) {
    const { task, round } = this.get(taskId, roundId);
    if (round.status !== 'applied' || !round.canContinue) throw new Error('请先确认本轮归档');
    const next = task.rounds.find(r => r.number === round.number + 1); if (next) return clone(next);
    const ids = task.snapshotIds.filter(id => !task.skippedIds.includes(id) && this.db.library.notes.some(n => n.id === id && !n.albumIds.length));
    const created = buildRound(this.db.library, ids, task.settings.allowNew, taskId, round.number + 1);
    task.rounds.push(created); this.db.readyAt[`${taskId}/${created.id}`] = Date.now() + this.delay;
    this.persist(); return clone(created);
  }
  async track(event: Omit<ArchiveEvent, 'at' | 'userId'>) {
    this.db.events.push({ ...event, userId: this.db.library.profile.id, at: Date.now() });
    this.db.events = this.db.events.slice(-500); this.persist();
  }
}
