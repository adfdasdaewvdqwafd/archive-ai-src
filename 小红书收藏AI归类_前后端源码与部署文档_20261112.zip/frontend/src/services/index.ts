import type { ArchiveService, Library, Round, Scenario } from '../../../contracts/archive';
import { GenerationPresentationStore } from '../domain/generation';
import { createScenarioSettings } from '../fixtures/library';
import { MockArchiveService, type StorageLike } from './mock';
import { HttpArchiveService } from './http';
import { rememberScenario, resolveScenario } from './scenarios';

export const DATA_MODE = import.meta.env.VITE_DATA_MODE || 'mock';
if (!['mock', 'http'].includes(DATA_MODE)) throw new Error('VITE_DATA_MODE 必须是 mock 或 http');
let storage: StorageLike;
export let storagePersistent = true;
try { localStorage.setItem('archive-storage-probe', '1'); localStorage.removeItem('archive-storage-probe'); storage = localStorage; }
catch { storagePersistent = false; const memory = new Map<string, string>(); storage = { getItem: k => memory.get(k) ?? null, setItem: (k, v) => { memory.set(k, v); } }; }
export const scenario = resolveScenario(new URLSearchParams(location.search).get('scenario'), storage);
export function createService(selected: Scenario): ArchiveService {
  return DATA_MODE === 'http' ? new HttpArchiveService(import.meta.env.VITE_API_BASE_URL || '/api') : new MockArchiveService(storage, selected);
}
export const service = createService(scenario);
export function selectDemoScenario(selected: Scenario) { rememberScenario(selected, storage); }
export function generationPresentation(selected: Scenario, round: Round, library: Library, create = true) {
  const store = new GenerationPresentationStore(storage, selected);
  return create ? store.getOrCreate(round.taskId, round.id, round.noteIds.length, library.albums.length > 0) : store.get(round.taskId, round.id);
}
export function resetGenerationPresentation(selected: Scenario) { new GenerationPresentationStore(storage, selected).reset(); }
if (DATA_MODE === 'mock') selectDemoScenario(scenario);
export async function getInitialSettings() { return createScenarioSettings(scenario, await service.getLibrary()); }
