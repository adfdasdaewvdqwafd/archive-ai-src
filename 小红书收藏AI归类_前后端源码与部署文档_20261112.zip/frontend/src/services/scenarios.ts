import type { Scenario } from '../../../contracts/archive';
import { SCENARIOS } from '../fixtures/library';
import type { StorageLike } from './mock';

const selectionKey = 'archive-demo-user-scenario';
export const USER_SCENARIOS = [
  { id: 'no-album', label: '从未整理过收藏' },
  { id: 'main', label: '近期未整理收藏' },
] as const;

export function resolveScenario(requested: string | null, storage: StorageLike): Scenario {
  if (SCENARIOS.some(item => item.id === requested)) return requested as Scenario;
  const saved = storage.getItem(selectionKey);
  return USER_SCENARIOS.find(item => item.id === saved)?.id ?? 'main';
}

export function rememberScenario(scenario: Scenario, storage: StorageLike) {
  if (USER_SCENARIOS.some(item => item.id === scenario)) storage.setItem(selectionKey, scenario);
}
