import type { ApplyRequest, ApplyResult, ArchiveService, ArchiveFeedback, FeedbackDetails, Library, Round, Settings, Album, ArchiveEvent } from '../../../contracts/archive';

export class HttpArchiveService implements ArchiveService {
  constructor(private base: string) {}
  private async request<T>(path: string, body?: unknown, method = body === undefined ? 'GET' : 'POST'): Promise<T> {
    const response = await fetch(`${this.base.replace(/\/$/, '')}${path}`, {
      method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body), signal: AbortSignal.timeout(20_000),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || `服务请求失败（${response.status}）`);
    return data as T;
  }
  private path(taskId: string, roundId: string) { return `/tasks/${encodeURIComponent(taskId)}/rounds/${encodeURIComponent(roundId)}`; }
  getLibrary() { return this.request<Library>('/library'); }
  getFeedback() { return this.request<ArchiveFeedback | null>('/feedback'); }
  offerFeedback(taskId: string) { return this.request<ArchiveFeedback | null>('/feedback/offer', { taskId }); }
  rateFeedback(rating: number) { return this.request<ArchiveFeedback>('/feedback/rating', { rating }); }
  submitFeedback(details: FeedbackDetails) { return this.request<ArchiveFeedback>('/feedback/details', details); }
  markReminderSeen() { return this.request<void>('/reminder/seen', {}); }
  createAlbum(name: string) { return this.request<Album>('/albums', { name, visibility: 'private' }); }
  startTask(settings: Settings) { return this.request<Round>('/tasks', settings); }
  getRound(taskId: string, roundId: string) { return this.request<Round>(this.path(taskId, roundId)); }
  cancelRound(taskId: string, roundId: string) { return this.request<void>(`${this.path(taskId, roundId)}/cancel`, {}); }
  adjustRound(taskId: string, roundId: string, noteIds: string[], destination: string | null) { return this.request<Round>(`${this.path(taskId, roundId)}/adjust`, { noteIds, destination }); }
  applyRound(taskId: string, roundId: string, request: ApplyRequest) { return this.request<ApplyResult>(`${this.path(taskId, roundId)}/apply`, request); }
  nextRound(taskId: string, roundId: string) { return this.request<Round>(`${this.path(taskId, roundId)}/next`, {}); }
  track(event: Omit<ArchiveEvent, 'at' | 'userId'>) { return this.request<void>('/events', event); }
}
