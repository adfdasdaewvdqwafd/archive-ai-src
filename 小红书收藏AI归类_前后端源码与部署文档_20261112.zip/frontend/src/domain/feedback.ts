import type { FeedbackDetails, FeedbackReason } from '../../../contracts/archive';

const IMPROVEMENT_REASONS: { id: FeedbackReason; label: string }[] = [
  { id: 'inaccurate', label: '分类不准确' },
  { id: 'fragmented', label: '专辑划分太零散' },
  { id: 'unclear_names', label: '专辑命名不清晰' },
  { id: 'missed_notes', label: '有笔记未归类' },
  { id: 'complex_steps', label: '操作步骤太多' },
  { id: 'other', label: '其他建议' },
];

const SATISFIED_REASONS: { id: FeedbackReason; label: string }[] = [
  { id: 'accurate', label: '分类准确' },
  { id: 'clear_grouping', label: '专辑划分合理' },
  { id: 'clear_names', label: '专辑命名清晰' },
  { id: 'existing_match', label: '已有专辑匹配好' },
  { id: 'time_saved', label: '省时省力' },
  { id: 'other', label: '其他建议' },
];

export const RATING_LABELS = ['很不满意', '不太满意', '一般', '满意', '很满意'];

export function validateRating(rating: number) {
  if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new Error('请选择1至5分');
}

export function getFeedbackConfig(rating: number) {
  validateRating(rating);
  return rating <= 3 ? {
    title: '哪些地方需要改进？', reasons: IMPROVEMENT_REASONS,
    placeholder: '哪些笔记分得不合适？你希望怎样调整？',
  } : {
    title: '哪些地方让你满意？', reasons: SATISFIED_REASONS,
    placeholder: '哪些地方帮到了你？还有什么可以改进？',
  };
}

export function normalizeFeedback(details: FeedbackDetails, rating: number): FeedbackDetails {
  const options = getFeedbackConfig(rating).reasons;
  if (details.reasons.some(id => !options.some(reason => reason.id === id))) throw new Error('请选择与本次评分对应的反馈原因');
  const comment = details.comment.trim();
  if (comment.length > 300) throw new Error('补充说明请控制在300字以内');
  const reasons = [...new Set(details.reasons)];
  if (!reasons.length && !comment) throw new Error('请选择一个反馈方向，或填写补充说明');
  return { reasons, comment };
}
