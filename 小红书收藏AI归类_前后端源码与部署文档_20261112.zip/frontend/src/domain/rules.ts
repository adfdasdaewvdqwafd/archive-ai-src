import type { ApplyResult, EligibilityConfig, Group, Library, Note, Round } from '../../../contracts/archive';

export const DEFAULT_ELIGIBILITY: EligibilityConfig = { minNotes: 50, minUnfiled: 30, inactiveDays: 7 };
export const DAY = 86_400_000;
export const unfiled = (library: Library) => library.notes.filter(n => !n.albumIds.length);
export function canOfferNextRound(round: Round, result: ApplyResult, library: Library) {
  if (round.status !== 'applied' || !round.allowNew || !round.canContinue || result.archivedCount <= 0 || result.unclassifiedCount <= 0) return false;
  if (result.taskId !== round.taskId || result.roundId !== round.id) return false;
  const remaining = new Set(unfiled(library).filter(note => note.accessible).map(note => note.id));
  return round.noteIds.some(id => remaining.has(id) && !round.skippedIds.includes(id));
}
export function eligible(library: Library, now: number, config = DEFAULT_ELIGIBILITY) {
  if (library.notes.length < config.minNotes) return false;
  if (!library.albums.length) return true;
  return unfiled(library).length >= config.minUnfiled &&
    (library.profile.lastMaintainedAt === null || now - library.profile.lastMaintainedAt >= config.inactiveDays * DAY);
}
export function inRange(notes: Note[], days: number | null, at: number) {
  if (days === null) return notes;
  if (!Number.isInteger(days) || days <= 0) throw new Error('自定义天数须为正整数');
  return notes.filter(n => n.collectedAt >= at - days * DAY && n.collectedAt <= at);
}
export const TOPICS: Record<string, { name: string; reason: string }> = {
  guitar: { name: '吉他', reason: '根据吉他、演奏、指弹等内容归类。' },
  travel: { name: '旅行', reason: '根据旅行路线、行程攻略与行李清单归类。' },
  food: { name: '美食', reason: '根据家常菜谱、食材与烹饪步骤归类。' },
  fitness: { name: '健身', reason: '根据力量训练、器械与动作练习归类。' },
  photography: { name: '摄影', reason: '根据相机设置、曝光与构图知识归类。' },
  home: { name: '家居', reason: '根据卧室布置、衣柜与收纳方案归类。' },
  outfit: { name: '穿搭', reason: '根据服饰搭配、单品与配色归类。' },
  pets: { name: '宠物', reason: '根据猫狗日常与养宠内容归类。' },
  career: { name: '求职准备', reason: '根据校招、offer、求职技巧归类。' },
  life: { name: '生活技巧', reason: '根据生活经验、实用妙招归类。' },
  sports: { name: '运动娱乐', reason: '根据运动、赛事、娱乐内容归类。' },
  scenery: { name: '风景摄影', reason: '根据山川、风景、摄影内容归类。' },
};
export function buildRound(library: Library, noteIds: string[], allowNew: boolean, taskId: string, number: number): Round {
  const notes = noteIds.map(id => library.notes.find(n => n.id === id)).filter((n): n is Note => !!n && !n.albumIds.length);
  const existing: Group[] = [];
  const candidates: { group: Group; recent: number }[] = [];
  for (const [topic, info] of Object.entries(TOPICS)) {
    const matches = notes.filter(n => (n.suggestedTopic ?? n.topic) === topic && n.accessible);
    if (!matches.length) continue;
    const album = library.albums.find(a => a.name === info.name);
    if (album) existing.push({ ...album, isNew: false, reason: info.reason, noteIds: matches.map(n => n.id) });
    else if (matches.length >= 4) candidates.push({
      group: { id: `suggestion-${taskId}-${number}-${topic}`, ...info, visibility: 'private', isNew: true, noteIds: matches.map(n => n.id) },
      recent: Math.max(...matches.map(n => n.collectedAt)),
    });
  }
  candidates.sort((a, b) => b.group.noteIds.length - a.group.noteIds.length || b.recent - a.recent);
  const selected = allowNew ? candidates.slice(0, 5).map(c => c.group) : [];
  const groups = [...existing, ...selected].sort((a, b) => Object.values(TOPICS).findIndex(t => t.name === a.name) - Object.values(TOPICS).findIndex(t => t.name === b.name));
  const assigned = new Set(groups.flatMap(g => g.noteIds));
  const rest = notes.filter(n => !assigned.has(n.id)).map(n => n.id);
  return {
    id: `round-${number}`, taskId, number, noteIds: notes.map(n => n.id), allowNew, groups,
    unclassifiedIds: allowNew ? rest : [], skippedIds: [], hiddenCount: allowNew ? 0 : rest.length,
    candidateCount: candidates.length, canContinue: allowNew && candidates.length > 5, status: 'generating',
  };
}
export function moveNotes(round: Round, ids: string[], destination: string | null, library: Library): Round {
  ids = [...new Set(ids)];
  if (round.status !== 'preview') throw new Error('当前轮次不可调整');
  const accessible = new Set(library.notes.filter(n => n.accessible).map(n => n.id));
  const visible = new Set([...round.groups.flatMap(g => g.noteIds), ...round.unclassifiedIds]);
  if (!ids.length || ids.some(id => !round.noteIds.includes(id) || !visible.has(id) || !accessible.has(id))) throw new Error('请选择本轮可访问的笔记');
  let groups = round.groups.map(g => ({ ...g, noteIds: g.noteIds.filter(id => !ids.includes(id)) }));
  if (destination) {
    let target = groups.find(g => g.id === destination);
    if (!target) {
      const album = library.albums.find(a => a.id === destination);
      if (!album) throw new Error('目的地不存在');
      target = { ...album, isNew: false, noteIds: [], reason: '你手动选择了这个目的地。' };
      groups = [...groups, target];
    }
    target.noteIds.push(...ids);
  }
  const assigned = new Set(groups.flatMap(g => g.noteIds));
  return { ...round, groups,
    unclassifiedIds: round.allowNew ? round.noteIds.filter(id => !assigned.has(id)) : [],
    hiddenCount: round.allowNew ? 0 : round.noteIds.filter(id => !assigned.has(id)).length,
    skippedIds: destination ? round.skippedIds.filter(id => !ids.includes(id)) : [...new Set([...round.skippedIds, ...ids])],
  };
}
export function publicTargets(round: Round): Group[] { return round.groups.filter(g => g.visibility === 'public' && g.noteIds.length); }
export const plannedCount = (round: Round) => round.groups.reduce((sum, g) => sum + g.noteIds.length, 0);
