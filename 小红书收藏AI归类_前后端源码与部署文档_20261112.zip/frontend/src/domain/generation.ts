import catalog from '../../../backend/fixtures/progress-copies.v2.json';

type StageId = 'analyze_notes' | 'understand_albums' | 'generate_groups' | 'review_suggestions';
interface StageCopy { id: StageId; songId: string; sourceSong: string; copyText: string }
export interface GenerationTheme {
  singerId: string; singerName: string; copyGroupId: 'A' | 'B'; copyVersion: 'V2'; stages: StageCopy[];
}
export interface GenerationProgress extends Omit<GenerationTheme, 'stages'> {
  startedAt: number; currentStage: number; percent: number;
  stages: (StageCopy & { label: string; durationMs: number })[];
}
interface StorageLike { getItem(key: string): string | null; setItem(key: string, value: string): void }
interface Presentations { themes: Record<string, GenerationTheme>; rounds: Record<string, GenerationProgress> }

function sample(random: () => number) {
  const value = random();
  if (!Number.isFinite(value) || value < 0 || value >= 1) throw new Error('随机值须在[0,1)之间');
  return value;
}

export function selectGenerationTheme(random = Math.random): GenerationTheme {
  const singer = catalog.singers[Math.floor(sample(random) * catalog.singers.length)];
  const group = singer.groups[Math.floor(sample(random) * singer.groups.length)];
  return structuredClone({ singerId: singer.id, singerName: singer.name, copyGroupId: group.id, copyVersion: catalog.version, stages: group.stages }) as GenerationTheme;
}

export function scheduleGeneration(theme: GenerationTheme, noteCount: number, hasAlbums: boolean, startedAt = Date.now(), random = Math.random): GenerationProgress {
  const labels = [`正在分析${noteCount}篇笔记`, hasAlbums ? '正在了解现有专辑' : '正在梳理分类方向', '正在生成归类建议', '正在复查归类建议'];
  return {
    singerId: theme.singerId, singerName: theme.singerName, copyGroupId: theme.copyGroupId, copyVersion: theme.copyVersion,
    startedAt, currentStage: 0, percent: 0,
    stages: theme.stages.map((stage, index) => ({ ...stage, label: labels[index],
      copyText: !hasAlbums && stage.id === 'understand_albums' ? stage.sourceSong : stage.copyText,
      durationMs: 1500 + Math.floor(sample(random) * 501),
    })),
  };
}

export function generationReadyAt(progress: GenerationProgress) {
  return progress.startedAt + progress.stages.reduce((sum, stage) => sum + stage.durationMs, 0);
}

export function projectGeneration(progress: GenerationProgress, now: number, complete = false): GenerationProgress {
  const elapsed = Math.max(0, now - progress.startedAt);
  const total = generationReadyAt(progress) - progress.startedAt;
  let boundary = 0;
  let currentStage = progress.stages.length - 1;
  for (const [index, stage] of progress.stages.entries()) {
    boundary += stage.durationMs;
    if (elapsed < boundary) { currentStage = index; break; }
  }
  return { ...progress, currentStage, percent: complete ? 100 : total > 0 ? Math.min(99, Math.floor(elapsed / total * 100)) : 99 };
}

export function presentationFinished(progress: GenerationProgress, now = Date.now()) { return now >= generationReadyAt(progress); }

/** UI-only waiting state, deliberately separate from the archive service/contract. */
export class GenerationPresentationStore {
  private state: Presentations;
  private key: string;
  constructor(private storage: StorageLike, scope: string, private random = Math.random) {
    this.key = `archive-generation-presentation-v2:${scope}`;
    let saved: Presentations | null = null;
    try { saved = JSON.parse(storage.getItem(this.key) || 'null'); } catch { /* A corrupt presentation does not affect archive data. */ }
    this.state = saved?.themes && saved.rounds ? saved : { themes: {}, rounds: {} };
  }
  private persist() { this.storage.setItem(this.key, JSON.stringify(this.state)); }
  get(taskId: string, roundId: string) { return structuredClone(this.state.rounds[`${taskId}/${roundId}`] ?? null); }
  getOrCreate(taskId: string, roundId: string, noteCount: number, hasAlbums: boolean, now = Date.now()) {
    const existing = this.get(taskId, roundId); if (existing) return existing;
    const theme = this.state.themes[taskId] ??= selectGenerationTheme(this.random);
    const progress = scheduleGeneration(theme, noteCount, hasAlbums, now, this.random);
    this.state.rounds[`${taskId}/${roundId}`] = progress;
    this.persist(); return structuredClone(progress);
  }
  reset() { this.state = { themes: {}, rounds: {} }; this.persist(); }
}
