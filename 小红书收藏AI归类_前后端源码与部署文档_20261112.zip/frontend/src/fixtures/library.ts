import type { Library, Note, Scenario, Settings } from '../../../contracts/archive';
import { DAY } from '../domain/rules';
import seed from './notes.seed.json';

export const SCENARIOS: { id: Scenario; name: string; description: string }[] = [
  { id: 'main', name: '首次归档', description: '吉他专辑已有6篇 · 未归档53篇 · 6个新组分轮确认' },
  { id: 'existing', name: '仅匹配已有', description: '关闭新建：8篇加入吉他 · 45篇保持未归档' },
  { id: 'overflow', name: '超过五组', description: '6个候选新组 · 首轮42篇 · 下一轮穿搭6篇' },
  { id: 'five', name: '恰好五组', description: '穿搭仅3篇 · 5个候选新组 · 不询问继续' },
  { id: 'partial', name: '部分写入', description: '首轮计划42篇 · 实际41篇 · 未归类12篇' },
  { id: 'zero', name: '全部未写入', description: '已归档0篇 · 未归类53篇 · 原吉他6篇不变' },
  { id: 'error', name: '生成异常', description: '模拟生成失败 · 保留本轮选择与设置' },
  { id: 'empty', name: '没有匹配', description: '仅选择45篇非吉他内容 · 关闭新建 · 无匹配结果' },
  { id: 'ineligible', name: '不满足提醒资格', description: '收藏24篇 · 不展示主动提醒' },
  { id: 'no-album', name: '尚无专辑', description: '59篇全部未归档 · 关闭新建时禁用生成' },
  { id: 'public', name: '公开专辑确认', description: '唯一吉他专辑为公开 · 写入前需要确认' },
  { id: 'correction', name: '纠正AI误分', description: '两篇吉他笔记故意建议到摄影 · 支持单条或批量移回' },
];

export function createLibrary(scenario: Scenario, now = Date.now()): Library {
  let notes: Note[] = seed.map(({ ageDays, ...n }) => ({ ...n, albumIds: [...n.albumIds], tags: [...n.tags],
    kind: n.kind as Note['kind'], collectedAt: now - ageDays * DAY }));
  // Variant datasets keep the default library intact and reuse the same uploaded assets.
  if (scenario === 'five') notes = notes.filter(n => n.topic !== 'outfit' || Number(n.id.slice(-2)) <= 3);
  if (scenario === 'ineligible') notes = notes.slice(0, 24);
  if (scenario === 'no-album') notes.forEach(n => { n.albumIds = []; });
  if (scenario === 'correction') notes.forEach(n => {
    if (['note-guitar-07', 'note-guitar-08'].includes(n.id)) n.suggestedTopic = 'photography';
  });
  notes.sort((a, b) => b.collectedAt - a.collectedAt || a.id.localeCompare(b.id));
  return {
    profile: { id: 'demo-momo', name: 'momo', handle: 'momo_0618', bio: '练练琴，记录一点喜欢的日常。',
      lastMaintainedAt: scenario === 'no-album' ? null : now - 8 * DAY, reminderSeen: false },
    notes,
    albums: scenario === 'no-album' ? [] : [{ id: 'album-guitar', name: '吉他', visibility: scenario === 'public' ? 'public' : 'private' }],
  };
}

/** Recommended initial selection; callers may subsequently edit it freely. */
export function createScenarioSettings(scenario: Scenario, library: Library): Settings {
  const notes = library.notes.filter(n => !n.albumIds.length);
  return {
    noteIds: notes.filter(n => scenario !== 'empty' || n.topic !== 'guitar').map(n => n.id),
    allowNew: !['existing', 'empty'].includes(scenario),
    rangeLabel: scenario === 'empty' ? '自选非吉他笔记' : '全部',
  };
}

/** Scope presets exercise boundaries without inventing extra albums or notes. */
export function createBoundarySelections(library: Library): Record<string, string[]> {
  const available = library.notes.filter(n => !n.albumIds.length);
  const topic = (name: string, count: number) => available.filter(n => n.topic === name).slice(0, count).map(n => n.id);
  return {
    emptySelection: [],
    existingOneNote: topic('guitar', 1),
    newGroupThree: topic('photography', 3),
    newGroupFour: topic('photography', 4),
    exactFiveGroups: available.filter(n => !['outfit'].includes(n.topic)).map(n => n.id),
    fewerThanFiveGroups: available.filter(n => !['outfit', 'home'].includes(n.topic)).map(n => n.id),
    noExistingMatch: available.filter(n => n.topic !== 'guitar').map(n => n.id),
  };
}
