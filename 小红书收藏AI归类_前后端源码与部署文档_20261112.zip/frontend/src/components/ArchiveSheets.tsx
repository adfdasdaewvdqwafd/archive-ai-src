import { useState } from 'react';
import { Globe2, LockKeyhole } from 'lucide-react';
import type { Library, Note, Round } from '../../../contracts/archive';
import { publicTargets } from '../domain/rules';
import { CheckCircle, Cover, Sheet } from './ui';
export function NoteList({ title, notes, close, done }: { title: string; notes: Note[]; close: () => void; done: (ids: string[]) => void }) {
  const [ids, setIds] = useState<string[]>([]);
  const accessible = notes.filter(n => n.accessible).map(n => n.id);
  return <Sheet title={title} close={close} className="list-sheet"><div className="list-summary"><span>共{notes.length}篇 · 已选{ids.length}篇</span><button onClick={() => setIds(ids.length === accessible.length ? [] : accessible)}>全选可访问笔记</button></div><div className="sheet-list-grid">{notes.map(n => <button className="mini-note" role="checkbox" aria-checked={ids.includes(n.id)} disabled={!n.accessible} key={n.id} onClick={() => setIds(ids.includes(n.id) ? ids.filter(id => id !== n.id) : [...ids, n.id])}><div className="cover-select"><Cover note={n}/>{n.accessible && <CheckCircle checked={ids.includes(n.id)}/>}</div><p>{n.title}</p></button>)}</div>{!notes.length && <p className="empty-group-hint">这个建议暂时为空，确认时不会创建空专辑。</p>}<div className="sheet-actions"><button className="primary full" disabled={!ids.length} onClick={() => done(ids)}>调整所选{ids.length}篇</button></div></Sheet>;
}
export function AdjustSheet({ ids, round, library, busy, close, done }: { ids: string[]; round: Round; library: Library; busy: boolean; close: () => void; done: (destination: string | null) => void }) {
  const options = [...round.groups, ...library.albums.filter(a => !round.groups.some(g => g.id === a.id)).map(a => ({ ...a, isNew: false, noteIds: [] }))];
  const [destination, setDestination] = useState<string | null | undefined>();
  const notes = library.notes.filter(n => ids.includes(n.id));
  return <Sheet title="调整目的地" close={close}><p className="adjust-count">已选{ids.length}篇</p><div className="selected-note-list">{notes.map(n => <div key={n.id}><Cover note={n}/><span>{n.title}</span></div>)}</div><p className="destination-label">移动到</p><div className="destination-list">{options.map(group => <button role="radio" aria-checked={destination === group.id} key={group.id} onClick={() => setDestination(group.id)}><CheckCircle checked={destination === group.id}/><span><strong>{group.name} <small>{group.noteIds.length || library.notes.filter(n => n.albumIds.includes(group.id)).length}篇</small></strong><small>{group.isNew ? '拟新增' : '已有专辑'}</small></span><small>{group.visibility === 'private' ? <LockKeyhole size={12}/> : <Globe2 size={12}/>} {group.visibility === 'private' ? '私密' : '公开'}</small></button>)}<button role="radio" aria-checked={destination === null} onClick={() => setDestination(null)}><CheckCircle checked={destination === null}/><strong>跳过本轮</strong></button></div><button className="primary full" disabled={destination === undefined || busy} onClick={() => done(destination!)}>{busy ? '正在应用…' : '应用修改'}</button><p className="footer-hint">仅更新预览，尚未归档</p></Sheet>;
}
export function PublicSheet({ round, library, busy, close, done }: { round: Round; library: Library; busy: boolean; close: () => void; done: () => void }) {
  const [agreed, setAgreed] = useState(false);
  return <Sheet title="归入公开专辑？" close={close}>{publicTargets(round).map(group => <div className="public-target" key={group.id}><div><Globe2 size={14}/>{group.name} · 公开</div><p>这{group.noteIds.length}篇笔记将加入已有公开专辑，其他人可能看到它们与你的收藏关系。</p><div className="group-covers">{library.notes.filter(n => group.noteIds.includes(n.id)).slice(0, 3).map(n => <div className="mini-note" key={n.id}><Cover note={n}/><p>{n.title}</p></div>)}</div></div>)}<label className="public-consent"><input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)}/>我已了解，并同意加入公开专辑</label><div className="two-actions"><button className="secondary" disabled={busy} onClick={close}>返回调整</button><button className="primary" disabled={!agreed || busy} onClick={done}>{busy ? '正在归档…' : '确认归档'}</button></div></Sheet>;
}
export function CreateSheet({ busy, close, done }: { busy: boolean; close: () => void; done: (name: string) => void }) {
  const [name, setName] = useState('');
  return <Sheet title="创建新专辑" close={close}><form onSubmit={e => { e.preventDefault(); if (name.trim()) done(name); }}><label className="album-name-label" htmlFor="album-name">专辑名称</label><input className="album-name" id="album-name" maxLength={30} placeholder="给喜欢的内容起个名字" value={name} onChange={e => setName(e.target.value)}/><p className="private-default"><LockKeyhole size={14}/>新专辑默认私密</p><button className="primary full" disabled={!name.trim() || busy}>创建专辑</button></form></Sheet>;
}
