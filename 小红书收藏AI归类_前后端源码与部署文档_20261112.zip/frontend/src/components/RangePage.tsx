import { useState } from 'react';
import type { Note } from '../../../contracts/archive';
import { inRange } from '../domain/rules';
import { CheckCircle, Cover, Header } from './ui';

export function RangePage({ notes, selectedIds, initialDays, initialLabel, back, done }: {
  notes: Note[]; selectedIds: string[]; initialDays: number | null; initialLabel: string;
  back: () => void; done: (ids: string[], days: number | null, label: string) => void;
}) {
  const [at] = useState(Date.now());
  const [days, setDays] = useState(initialDays);
  const [label, setLabel] = useState(initialLabel);
  const [custom, setCustom] = useState(initialDays && ![7, 30, 90].includes(initialDays) ? String(initialDays) : '');
  const [selected, setSelected] = useState(selectedIds);
  const [customError, setCustomError] = useState('');
  const visible = inRange(notes, days, at);
  function choose(value: number | null, nextLabel: string) { setDays(value); setLabel(nextLabel); setSelected(inRange(notes, value, at).map(n => n.id)); setCustomError(''); }
  function applyCustom() {
    const value = Number(custom);
    if (!/^\d+$/.test(custom) || !Number.isSafeInteger(value) || value <= 0) { setCustomError('请输入正整数天数'); return; }
    choose(value, `近${value}天`);
  }
  const allSelected = visible.length > 0 && visible.every(n => selected.includes(n.id));
  return <div className="range-page"><Header title="调整范围" back={back} action={<button className="text-primary" onClick={() => done(selected, days, label)}>完成</button>}/><div className="range-controls"><h2>未归档{notes.length}篇</h2><div className="range-chips">{[[null, `全部（${notes.length}篇）`], [7, '近7天'], [30, '近30天'], [90, '近90天']].map(([value, text]) => <button key={String(value)} className={days === value ? 'selected' : ''} onClick={() => { setCustom(''); choose(value as number | null, value === null ? '全部' : `近${value}天`); }}>{text}</button>)}</div><form className="custom-days" onSubmit={e => { e.preventDefault(); applyCustom(); }}><label htmlFor="custom-days">自定义天数</label><input id="custom-days" aria-describedby="custom-error" inputMode="numeric" placeholder="—" value={custom} onChange={e => { setCustom(e.target.value); setCustomError(''); }}/><span>天</span><button type="submit">应用</button><small>按收藏时间筛选</small></form>{customError && <p id="custom-error" className="field-error" role="alert">{customError}</p>}</div><div className="range-summary"><strong>{label === '全部' ? '全部' : label}共{visible.length}篇 · 已选{selected.length}篇</strong><button onClick={() => setSelected(allSelected ? [] : visible.map(n => n.id))}><CheckCircle checked={allSelected}/>全选</button></div>{visible.length ? <div className="note-grid range-notes">{visible.map(note => <button key={note.id} className="note-tile" role="checkbox" aria-checked={selected.includes(note.id)} aria-label={`选择 ${note.title}`} onClick={() => setSelected(selected.includes(note.id) ? selected.filter(id => id !== note.id) : [...selected, note.id])}><div className="cover-select"><Cover note={note}/><CheckCircle checked={selected.includes(note.id)}/></div><h3>{note.title}</h3></button>)}</div> : <div className="inline-empty"><h3>这个范围内还没有笔记</h3><p>试试扩大天数，或选择全部。</p></div>}<footer className="sticky-footer range-footer"><strong>已选{selected.length}篇</strong><button className="primary" onClick={() => done(selected, days, label)}>完成</button></footer></div>;
}
