import { useEffect, useRef, type MouseEvent } from 'react';
import { Check, RotateCcw, SlidersHorizontal, X } from 'lucide-react';
import type { Library, Scenario } from '../../../contracts/archive';
import { DAY, eligible, unfiled } from '../domain/rules';
import { SCENARIOS } from '../fixtures/library';
import { USER_SCENARIOS } from '../services/scenarios';

function maintenanceLabel(library: Library) {
  const maintainedAt = library.profile.lastMaintainedAt;
  if (maintainedAt === null) return '暂无维护记录';
  const days = Math.floor(Math.max(0, Date.now() - maintainedAt) / DAY);
  return days === 0 ? '最近维护：今天' : `上次维护${days}天前`;
}

export function ScenarioConsole({ scenario, library, disabled, generating, persistent, change, open, setOpen, launcherVisible }: {
  scenario: Scenario; library: Library | null; disabled: boolean; generating: boolean;
  persistent: boolean; change: (scenario: Scenario, reset?: boolean) => void;
  open: boolean; setOpen: (open: boolean) => void;
  launcherVisible: boolean;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const label = USER_SCENARIOS.find(item => item.id === scenario)?.label ?? SCENARIOS.find(item => item.id === scenario)?.name;
  const qualified = library && eligible(library, Date.now());
  useEffect(() => {
    const dialog = dialogRef.current;
    if (open) {
      const previousOverflow = document.documentElement.style.overflow;
      document.documentElement.style.overflow = 'hidden';
      dialog?.showModal();
      return () => { dialog?.close(); document.documentElement.style.overflow = previousOverflow; };
    }
    buttonRef.current?.focus({ preventScroll: true });
  }, [open]);

  function dismissBackdrop(event: MouseEvent<HTMLDialogElement>) {
    if (event.target !== event.currentTarget) return;
    const rect = event.currentTarget.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) setOpen(false);
  }

  return <>
    {launcherVisible && <button ref={buttonRef} type="button" className="scenario-fab" aria-label="打开用户情景模拟" aria-haspopup="dialog" aria-expanded={open} title={`用户情景模拟 · ${label}`} onClick={() => setOpen(true)}>mock</button>}
    {open && <dialog ref={dialogRef} className="scenario-dialog" aria-labelledby="scenario-console-title" aria-describedby="scenario-console-description" onCancel={event => { event.preventDefault(); setOpen(false); }} onClick={dismissBackdrop}>
    <div className="scenario-console-heading"><span className="scenario-console-symbol"><SlidersHorizontal size={21}/></span><div><span className="scenario-console-tag">演示控制台</span><h2 id="scenario-console-title">用户情景模拟</h2></div><button type="button" className="icon-button" aria-label="收起情景控制台" autoFocus onClick={() => setOpen(false)}><X size={19}/></button></div>
    <p id="scenario-console-description" className="scenario-console-description">切换收藏整理情景，体验不同用户的AI归类流程。</p>
    <div className="scenario-console-actions" role="group" aria-label="切换用户情景" aria-busy={disabled}>
      {USER_SCENARIOS.map(item => <button key={item.id} type="button" aria-label={item.label} aria-pressed={scenario === item.id} className={`scenario-option${scenario === item.id ? ' active' : ''}`} disabled={disabled} onClick={() => change(item.id, true)}><span><strong>{item.label}</strong><small>{item.id === 'no-album' ? '收藏≥50篇 · 尚未建立专辑' : '收藏≥50篇 · 未归档≥30篇 · 至少7天未维护'}</small></span><span className="scenario-option-check">{scenario === item.id && <Check size={13} strokeWidth={3}/>}</span></button>)}
      <button type="button" className="scenario-reset" disabled={disabled} onClick={() => change(scenario, true)} title="恢复当前情景的初始数据，清除该情景的任务与结果"><RotateCcw size={15}/><span>重置</span></button>
    </div>
    <div className="scenario-console-status" role="status" aria-live="polite">
      <strong>当前：{label}</strong>
      {library ? <><p>收藏{library.notes.length}篇 · 未归档{unfiled(library).length}篇 · 专辑{library.albums.length}个</p><p>{maintenanceLabel(library)}<span className={qualified ? 'scenario-qualified' : ''}> · {qualified ? '满足提醒条件' : '未满足提醒条件'}</span></p></> : <p>正在加载情景数据…</p>}
    </div>
    <p className="scenario-console-hint">{generating ? '正在生成建议，请取消或完成后切换情景。' : '选择情景会重置该情景，重新开始体验。'}{!persistent && '当前浏览器无法持久保存，刷新后进度将丢失。'}</p>
    </dialog>}
  </>;
}
