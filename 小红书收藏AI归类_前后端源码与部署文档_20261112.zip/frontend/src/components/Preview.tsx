import { ChevronRight } from 'lucide-react';
import type { Library, Note, Round } from '../../../contracts/archive';
import { plannedCount } from '../domain/rules';
import { CheckCircle, Cover, GroupCard, Header } from './ui';

export function Preview({ round, library, selection, selecting, busy, back, setSelecting, toggleSelect, openNote, openAll, adjust, confirm }: {
  round: Round; library: Library; selection: string[]; selecting: boolean; busy: boolean;
  back: () => void; setSelecting: (v: boolean) => void; toggleSelect: (id: string) => void;
  openNote: (n: Note) => void; openAll: (ids: string[], title: string) => void; adjust: (ids: string[]) => void; confirm: () => void;
}) {
  const getNotes = (ids: string[]) => ids.map(id => library.notes.find(n => n.id === id)).filter((n): n is Note => !!n);
  const planned = plannedCount(round);
  return <div className="preview-page">
    <Header title="归类预览" back={back} action={<button className="text-primary" onClick={() => setSelecting(!selecting)}>{selecting ? '取消选择' : '选择'}</button>}/>
    <div className="preview-content">
      <div className="preview-summary"><strong>{round.allowNew ? `已选${round.noteIds.length}篇 · 建议归档${planned}篇` : `可归类${planned}篇 · 仅归入已有专辑`}</strong><span>确认前不会创建专辑</span></div>
      {round.number > 1 && <div className="round-label">第{round.number}轮 · 仅处理尚未归档的笔记</div>}
      {round.groups.map(group => <GroupCard key={group.id} group={group} notes={getNotes(group.noteIds)} adjusting={selecting} selection={selection} onSelect={toggleSelect} onNote={openNote} onAdjust={() => openAll(group.noteIds, `调整 · ${group.name}`)} onAll={() => openAll(group.noteIds, group.name)}/>)}
      {round.allowNew && round.unclassifiedIds.length > 0 && <section className="unclassified"><div className="unclassified-top"><strong>未归类 {round.unclassifiedIds.length}篇</strong><div className="unclassified-thumbs">{getNotes(round.unclassifiedIds).slice(0, 3).map(n => <Cover key={n.id} note={n}/>)}</div><button className="adjust-link" onClick={() => openAll(round.unclassifiedIds, '未归类')}>调整<ChevronRight size={12}/></button></div></section>}
      {!round.groups.length && <div className="inline-empty"><div className="empty-symbol">⌁</div><h3>暂时没有匹配的归类建议</h3><p>{round.allowNew ? '可以手动调整未归类笔记，或返回设置。' : '试试允许新建专辑，或调整归类范围。'}</p><button onClick={back}>返回设置<ChevronRight size={14}/></button></div>}
    </div>
    <footer className="sticky-footer">{selecting ? <div className="selection-toolbar"><span><CheckCircle checked={selection.length > 0}/>已选{selection.length}篇</span><button className="primary" disabled={!selection.length || busy} onClick={() => adjust(selection)}>调整目的地</button></div> : <button className="primary full" disabled={busy || planned === 0} onClick={confirm}>{busy ? '正在归档…' : `确认归档${planned}篇`}</button>}</footer>
  </div>;
}
