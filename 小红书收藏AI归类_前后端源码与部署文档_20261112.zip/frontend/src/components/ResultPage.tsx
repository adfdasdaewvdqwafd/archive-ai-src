import { Bookmark, Check, FolderPlus } from 'lucide-react';
import type { ApplyResult } from '../../../contracts/archive';
import { Header } from './ui';

export function ResultPage({ result, offerNext, hasSkipped, busy, continueRound, finish }: {
  result: ApplyResult; offerNext: boolean; hasSkipped: boolean; busy: boolean;
  continueRound: () => void; finish: (tab: 'notes' | 'albums') => void;
}) {
  return <div className={`result-page${offerNext ? ' has-continuation' : ''}`}>
    <Header title="归档结果" back={() => { if (!busy) finish('notes'); }}/>
    <div className="result-center">
      {result.archivedCount > 0 ? <div className="result-check"><Check size={29}/></div> : <Bookmark size={44} strokeWidth={1.4}/>}
      <h2>已归档{result.archivedCount}篇</h2><p>未归类{result.unclassifiedCount}篇</p>
      {offerNext && <section className="result-continuation" aria-labelledby="result-continuation-title"><div className="result-continuation-limit"><FolderPlus size={16}/><span>每次最多新增5个专辑</span></div><h3 id="result-continuation-title">还有{result.unclassifiedCount}篇笔记未归类，是否继续？</h3><p>本轮已完成，继续后再生成下一轮建议。</p>{hasSkipped && <small>已跳过的笔记不会进入下一轮。</small>}</section>}
    </div>
    <footer className="sticky-footer">
      {offerNext ? <><button className="primary full" disabled={busy} onClick={continueRound}>{busy ? '正在开始下一轮…' : '继续归类'}</button><button className="secondary full" disabled={busy} onClick={() => finish('notes')}>暂不继续</button><button className="plain full result-view-albums" disabled={busy} onClick={() => finish('albums')}>查看专辑</button></> : <><button className="primary full" disabled={busy} onClick={() => finish('albums')}>查看专辑</button><button className="secondary full" disabled={busy} onClick={() => finish('notes')}>完成</button></>}
    </footer>
  </div>;
}
