import { createContext, useContext, useEffect, useRef, type ReactNode } from 'react';
import { ArrowLeft, Check, ChevronRight, LockKeyhole, Play, X } from 'lucide-react';
import type { Group, Note } from '../../../contracts/archive';

export const NoticeContext = createContext({ message: '', dismiss: () => {} });

export function imageUrl(path: string) { return `${import.meta.env.BASE_URL}${path}`; }
export function Cover({ note, className = '' }: { note: Note; className?: string }) {
  return <div className={`cover ${className}`}><img src={imageUrl(note.cover)} alt="" loading="lazy" onError={e => { e.currentTarget.onerror = null; e.currentTarget.src = imageUrl('covers/fallback.svg'); }}/>{note.kind === 'video' && <span className="video-mark"><Play size={10} fill="currentColor" /></span>}{!note.accessible && <span className="unavailable-cover">暂不可访问</span>}</div>;
}
export function CheckCircle({ checked }: { checked: boolean }) { return <span className={`check-circle ${checked ? 'checked' : ''}`}>{checked && <Check size={13} strokeWidth={3}/>}</span>; }
export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return <button type="button" className={`toggle ${checked ? 'on' : ''}`} role="switch" aria-checked={checked} aria-label={label} onClick={onChange}><span/></button>;
}
export function Header({ title, back, action }: { title: string; back: () => void; action?: ReactNode }) {
  return <header className="page-header"><button className="icon-button" onClick={back} aria-label="返回"><ArrowLeft size={22}/></button><h1>{title}</h1><div className="header-action">{action}</div></header>;
}
export function Sheet({ title, children, close, className = '' }: { title: string; children: ReactNode; close: () => void; className?: string }) {
  const notice = useContext(NoticeContext);
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => { const dialog = ref.current; dialog?.showModal(); return () => dialog?.close(); }, []);
  return <dialog ref={ref} className={`sheet ${className}`} aria-label={title} onCancel={e => { e.preventDefault(); close(); }} onClick={e => { if (e.target === e.currentTarget) close(); }}><div className="sheet-inner"><div className="sheet-handle"/><div className="sheet-heading"><h2>{title}</h2><button className="icon-button" aria-label="关闭" onClick={close}><X size={20}/></button></div>{children}{notice.message && <div className="sheet-notice" role="alert">{notice.message}<button aria-label="关闭提示" onClick={notice.dismiss}><X size={14}/></button></div>}</div></dialog>;
}
export function GroupCard({ group, notes, adjusting, onAdjust, onAll, onNote, selection, onSelect }: {
  group: Group; notes: Note[]; adjusting: boolean; onAdjust: () => void; onAll: () => void;
  onNote: (note: Note) => void; selection: string[]; onSelect: (id: string) => void;
}) {
  return <article className="group-card"><div className="group-title"><h2>{group.name} <span>{group.noteIds.length}篇</span></h2><span className={`badge ${group.isNew ? 'new' : ''}`}>{group.isNew ? '拟新增' : '已有'}</span><span className="badge visibility">{group.visibility === 'private' && <LockKeyhole size={9}/>} {group.visibility === 'private' ? '私密' : '公开'}</span><button className="adjust-link" onClick={onAdjust}>调整<ChevronRight size={12}/></button></div><p className="group-reason">{group.reason}</p><div className="group-covers">{notes.slice(0, 3).map(note => <button key={note.id} className="mini-note" onClick={() => adjusting ? onSelect(note.id) : onNote(note)} disabled={adjusting && !note.accessible}><div className="cover-select"><Cover note={note}/>{adjusting && <CheckCircle checked={selection.includes(note.id)}/>}</div><p>{note.title}</p></button>)}</div><button className="view-all" onClick={onAll}>查看全部{group.noteIds.length}篇<ChevronRight size={12}/></button></article>;
}
