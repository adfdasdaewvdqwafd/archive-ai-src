import { useEffect, useState } from 'react';
import { Check, Sparkles } from 'lucide-react';
import type { Library, Round } from '../../../contracts/archive';
import { presentationFinished, projectGeneration, type GenerationProgress } from '../domain/generation';
import { Cover, Header } from './ui';

export function GenerationPage({ round, library, presentation, busy, cancel }: {
  round: Round; library: Library; busy: boolean; cancel: () => void;
  presentation: GenerationProgress | null;
}) {
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    setNow(Date.now());
    const timer = setInterval(() => setNow(Date.now()), 100);
    return () => clearInterval(timer);
  }, [round.taskId, round.id]);
  const progress = presentation ? projectGeneration(presentation, now) : null;
  const stage = progress?.stages[progress.currentStage];
  const stillWaiting = !!presentation && presentationFinished(presentation, now) && round.status === 'generating';
  return <div className="generation-page staged-generation">
    <Header title="正在整理归类建议" back={cancel}/>
    <div className="generation-center">
      <div className="generation-visual" aria-hidden="true"><div className="floating-covers">{library.notes.filter(note => round.noteIds.includes(note.id)).slice(0, 3).map(note => <Cover note={note} key={note.id}/>)}</div><span className="generation-sparkle"><Sparkles size={24}/></span></div>
      <div className="generation-stage-line" role="status" aria-live="polite" aria-atomic="true"><h2>{stillWaiting ? '建议仍在生成，请稍候…' : stage?.label ?? '正在生成归类建议'}</h2>{stage && !stillWaiting && <><span className="generation-divider" aria-hidden="true">｜</span><span className="generation-copy" title={`灵感来自${progress?.singerName}《${stage.sourceSong}》`}>{stage.copyText}</span></>}</div>
      <p className="generation-assurance">先生成建议，确认后再归档。</p>
      {progress ? <>
        <div className="generation-meter-label"><span>阶段 {progress.currentStage + 1}/4</span><span>{progress.percent}%</span></div>
        <div className="generation-meter" role="progressbar" aria-label="归类建议生成进度" aria-valuemin={0} aria-valuemax={100} aria-valuenow={progress.percent} aria-valuetext={`第${progress.currentStage + 1}阶段，共4阶段：${stage?.label}`}><span style={{ width: `${progress.percent}%` }}/></div>
        <ol className="generation-stages" aria-label="归类进度步骤">{progress.stages.map((item, index) => <li key={item.id} className={index < progress.currentStage ? 'complete' : index === progress.currentStage ? 'active' : ''} aria-current={index === progress.currentStage ? 'step' : undefined}><span className="generation-stage-marker">{index < progress.currentStage ? <Check size={13} strokeWidth={2.5}/> : index + 1}</span><span>{item.label.replace(/^正在/, '')}</span><small>{index < progress.currentStage ? '已完成' : index === progress.currentStage ? '进行中' : '等待中'}</small></li>)}</ol>
      </> : <div className="indeterminate"><span/></div>}
    </div>
    <footer className="generation-footer"><p>取消不会改变笔记或专辑。</p><button className="secondary full" onClick={cancel} disabled={busy}>{busy ? '正在取消…' : '取消'}</button></footer>
  </div>;
}
