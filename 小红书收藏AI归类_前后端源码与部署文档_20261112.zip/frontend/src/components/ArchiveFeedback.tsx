import { useEffect, useState } from 'react';
import { CheckCircle2, ChevronRight, MessageSquareText, Star, X } from 'lucide-react';
import type { ArchiveFeedback as Feedback, FeedbackDetails, FeedbackReason } from '../../../contracts/archive';
import { getFeedbackConfig, RATING_LABELS } from '../domain/feedback';
import { Sheet } from './ui';

export function ArchiveFeedback({ feedback, ratingOpen, visible, busy, dismissRating, rate, submit }: {
  feedback: Feedback; ratingOpen: boolean; visible: boolean; busy: boolean;
  dismissRating: () => void; rate: (rating: number) => void;
  submit: (details: FeedbackDetails) => Promise<boolean>;
}) {
  const [hover, setHover] = useState(0);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [reasons, setReasons] = useState<FeedbackReason[]>(feedback.reasons);
  const [comment, setComment] = useState(feedback.comment);
  const feedbackConfig = feedback.rating === null ? null : getFeedbackConfig(feedback.rating);
  useEffect(() => { if (!visible) setDetailsOpen(false); }, [visible]);
  useEffect(() => {
    if (!detailsOpen) return;
    const previous = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    return () => { document.documentElement.style.overflow = previous; };
  }, [detailsOpen]);
  if (!visible || feedback.submittedAt !== null) return null;

  return <>
    {ratingOpen && feedback.rating === null && <section className="rating-prompt" role="dialog" aria-modal="false" aria-labelledby="rating-prompt-title">
      <div className="rating-prompt-title"><span className="rating-prompt-symbol"><MessageSquareText size={16}/></span><h2 id="rating-prompt-title">这次AI归类，你满意吗？</h2><button type="button" className="icon-button" aria-label="暂不评分" disabled={busy} onClick={dismissRating}><X size={16}/></button></div>
      <p>点选星星，为这次归类结果打个分</p>
      <div className="rating-stars" role="group" aria-label="归类满意度评分" onMouseLeave={() => setHover(0)}>{RATING_LABELS.map((label, index) => <button key={label} type="button" aria-label={`评分${index + 1}分，${label}`} disabled={busy} onMouseEnter={() => setHover(index + 1)} onFocus={() => setHover(index + 1)} onBlur={() => setHover(0)} onClick={() => rate(index + 1)}><Star size={28} className={hover >= index + 1 ? 'filled' : ''} fill={hover >= index + 1 ? 'currentColor' : 'none'} strokeWidth={1.5}/><span>{index + 1}分</span></button>)}</div>
      <div className="rating-scale"><span>很不满意</span><span>{busy ? '正在保存…' : '很满意'}</span></div>
    </section>}
    {feedback.rating !== null && !detailsOpen && <button type="button" className="feedback-bar" onClick={() => setDetailsOpen(true)} aria-label="已反馈，可选择具体理由，去选择"><CheckCircle2 size={21} fill="white" stroke="#303035"/><span>已反馈，可选择具体理由</span><strong>去选择<ChevronRight size={16}/></strong></button>}
    {detailsOpen && feedback.rating !== null && feedbackConfig && <Sheet title="聊聊这次归类体验" close={() => { if (!busy) setDetailsOpen(false); }} className="feedback-sheet"><form onSubmit={event => { event.preventDefault(); void submit({ reasons, comment }).then(saved => { if (saved) setDetailsOpen(false); }); }}>
      <p className="feedback-rating-summary"><Star size={15} fill="currentColor"/>本次评分：{feedback.rating}分<span>{RATING_LABELS[feedback.rating - 1]}</span></p>
      <h3>{feedbackConfig.title}</h3><p className="feedback-sheet-hint">可多选，也可以直接填写建议。</p>
      <div className="feedback-reasons" role="group" aria-label="反馈方向">{feedbackConfig.reasons.map(reason => <button type="button" key={reason.id} aria-pressed={reasons.includes(reason.id)} disabled={busy} onClick={() => setReasons(current => current.includes(reason.id) ? current.filter(id => id !== reason.id) : [...current, reason.id])}>{reason.label}</button>)}</div>
      <label htmlFor="feedback-comment">补充说明<span>（选填）</span></label><textarea id="feedback-comment" maxLength={300} rows={4} value={comment} disabled={busy} onChange={event => setComment(event.target.value)} placeholder={feedbackConfig.placeholder}/><p className="feedback-counter">{comment.length}/300</p>
      <div className="feedback-submit"><button className="primary full" disabled={busy || (!reasons.length && !comment.trim())}>{busy ? '正在提交…' : '提交反馈'}</button></div>
    </form></Sheet>}
  </>;
}
