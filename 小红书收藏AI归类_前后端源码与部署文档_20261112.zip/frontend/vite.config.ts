import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

export default defineConfig(({ mode }) => {
  const root = fileURLToPath(new URL('..', import.meta.url));
  const env = loadEnv(mode, root, '');
  return {
    root: fileURLToPath(new URL('.', import.meta.url)), envDir: root,
    base: env.VITE_BASE_PATH || './', plugins: [react()],
    server: { port: 5173, strictPort: true, proxy: env.API_PROXY_TARGET ? { '/api': env.API_PROXY_TARGET } : undefined },
    build: { outDir: '../dist', emptyOutDir: true, target: 'es2020' },
  };
});
