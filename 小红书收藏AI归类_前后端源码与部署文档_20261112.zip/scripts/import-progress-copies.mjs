import { readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const root = new URL('../', import.meta.url);
const source = 'backend/content/小红书AI归类_进度步骤与歌手主题文案库_V1.md';
const markdown = readFileSync(new URL(source, root), 'utf8');
const singerIds = { '五月天': 'mayday', '林俊杰': 'jj-lin', '薛之谦': 'joker-xue', '邓紫棋': 'gem', '李荣浩': 'li-ronghao', '周杰伦': 'jay-chou', '周深': 'zhou-shen', '张杰': 'zhang-jie', '毛不易': 'mao-buyi', '汪苏泷': 'silence-wang', '单依纯': 'shan-yichun' };
const stageIds = { '分析笔记': 'analyze_notes', '了解专辑': 'understand_albums', '生成建议': 'generate_groups', '复查建议': 'review_suggestions' };
const singers = [];
let current;
for (const line of markdown.split(/\r?\n/)) {
  const heading = line.match(/^### \d+ ([^｜]+)(?:｜.*)?$/u);
  if (heading) {
    const name = heading[1].trim();
    if (!singerIds[name]) throw new Error(`未知歌手：${name}`);
    current = { id: singerIds[name], name, groups: [{ id: 'A', stages: [] }, { id: 'B', stages: [] }] };
    singers.push(current);
  }
  if (!current || !line.startsWith('|')) continue;
  const cells = line.split('|').slice(1, -1).map(cell => cell.trim());
  if (cells.length !== 5 || !stageIds[cells[0]]) continue;
  for (const [index, group] of current.groups.entries()) {
    const sourceSong = cells[1 + index * 2].replace(/[《》]/gu, '');
    const copyText = cells[2 + index * 2];
    if ([...copyText].length > 8 || !copyText.includes(sourceSong) || [...sourceSong].length > 8) throw new Error(`文案校验失败：${current.name} ${group.id} ${copyText}`);
    group.stages.push({ id: stageIds[cells[0]], songId: `${current.id}-${group.id.toLowerCase()}-${stageIds[cells[0]]}`, sourceSong, copyText });
  }
}
if (singers.length !== 11) throw new Error('应包含11位歌手');
for (const singer of singers) {
  if (singer.groups.some(group => group.stages.map(stage => stage.id).join() !== Object.values(stageIds).join())) throw new Error(`${singer.name}阶段不完整`);
  if (new Set(singer.groups.flatMap(group => group.stages.map(stage => stage.sourceSong))).size !== 8) throw new Error(`${singer.name}歌曲重复`);
}
const target = new URL('backend/fixtures/progress-copies.v2.json', root);
mkdirSync(new URL('.', target), { recursive: true });
writeFileSync(target, `${JSON.stringify({ version: 'V2', source, singers }, null, 2)}\n`, 'utf8');
console.log(`已导入11位歌手、22组、88条文案：${fileURLToPath(target)}`);
