import assert from 'node:assert/strict';
const base = new URL(process.argv[2] || 'http://127.0.0.1:3000/');
async function check(path, expected, options) {
  const url = new URL(path, base); const response = await fetch(url, { redirect: 'manual', ...options });
  assert.equal(response.status, expected, `${url.pathname} should return ${expected}`);
  console.log(`${response.status} ${url.pathname}`); return response;
}
await check('/healthz', 200);
const response = await check('./', 200); const html = await response.text();
assert.match(response.headers.get('content-type'), /text\/html/);
const resources = [...html.matchAll(/(?:src|href)="([^"]+)"/g)].map(m => m[1]).filter(p => p.includes('/assets/'));
assert.ok(resources.length >= 2, 'Expected bundled JS and CSS');
for (const resource of resources) { const asset = await check(resource, 200); assert.match(asset.headers.get('cache-control'), /immutable/); }
const cover = await check('covers/uploaded/guitar/01.jpg', 200); assert.match(cover.headers.get('content-type'), /image\/jpeg/);
await check('./', 200, { method: 'HEAD' });
await check('.env', 404);
const api = await check('api/library', 501); assert.ok((await api.json()).message);
await check('..%2fpackage.json', 403);
if (base.pathname !== '/') { const redirect = await fetch(`${base.origin}${base.pathname.replace(/\/$/, '')}`, { redirect: 'manual' }); assert.equal(redirect.status, 308); }
console.log('Production smoke checks passed.');
