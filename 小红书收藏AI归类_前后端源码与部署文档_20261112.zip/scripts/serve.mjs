import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { dirname, extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '../dist');
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';
const prefix = `/${(process.env.APP_BASE_PATH || '').replace(/^\/+|\/+$/g, '')}`.replace(/\/$/, '');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.jpg': 'image/jpeg', '.png': 'image/png', '.ico': 'image/x-icon' };
function json(res, code, data) { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); }
const server = createServer(async (req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'same-origin');
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); } catch { return json(res, 400, { message: 'Invalid URL' }); }
  if (pathname === '/healthz') return json(res, 200, { status: 'ok', service: 'collection-archive-frontend' });
  if (prefix && pathname === prefix) { res.writeHead(308, { Location: `${prefix}/${new URL(req.url, 'http://localhost').search}` }); return res.end(); }
  if (prefix && !pathname.startsWith(`${prefix}/`)) return json(res, 404, { message: 'Not found' });
  const relative = pathname.slice(prefix.length);
  if (relative === '/api' || relative.startsWith('/api/')) return json(res, 501, { message: '尚未连接后端服务，请配置 API 服务或使用 mock 演示模式。' });
  if (!['GET', 'HEAD'].includes(req.method)) return json(res, 405, { message: 'Method not allowed' });
  const path = resolve(root, `.${relative === '/' ? '/index.html' : relative}`);
  if (!path.startsWith(`${root}${sep}`)) return json(res, 403, { message: 'Forbidden' });
  try {
    const info = await stat(path); if (!info.isFile()) return json(res, 404, { message: 'Not found' });
    res.writeHead(200, { 'Content-Type': mime[extname(path)] || 'application/octet-stream', 'Content-Length': info.size, 'Cache-Control': relative.startsWith('/assets/') ? 'public, max-age=31536000, immutable' : 'no-cache' });
    if (req.method === 'HEAD') return res.end();
    const stream = createReadStream(path); stream.on('error', () => res.destroy()); stream.pipe(res);
  } catch { json(res, 404, { message: 'Not found. Run the production build before starting.' }); }
});
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
server.listen(port, host, () => console.log(`Collection Archive: http://127.0.0.1:${port}${prefix}/`));
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => process.exit(0)));
