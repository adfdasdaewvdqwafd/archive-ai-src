import { describe, expect, it } from 'vitest';
import { rememberScenario, resolveScenario } from '../frontend/src/services/scenarios';
import type { StorageLike } from '../frontend/src/services/mock';

function memory(): StorageLike {
  const values = new Map<string, string>();
  return { getItem: key => values.get(key) ?? null, setItem: (key, value) => { values.set(key, value); } };
}

describe('控制台情景选择', () => {
  it('首次默认近期未整理，重新打开恢复上次选择，显式链接优先', () => {
    const storage = memory();
    expect(resolveScenario(null, storage)).toBe('main');
    rememberScenario('no-album', storage);
    expect(resolveScenario(null, storage)).toBe('no-album');
    expect(resolveScenario('main', storage)).toBe('main');
    expect(resolveScenario('public', storage)).toBe('public');
    expect(resolveScenario('invalid', storage)).toBe('no-album');
    rememberScenario('main', storage);
    expect(resolveScenario(null, storage)).toBe('main');
  });
  it('详细演示场景不覆盖用户情景的选择，损坏的选择回退到默认', () => {
    const storage = memory();
    rememberScenario('no-album', storage);
    rememberScenario('error', storage);
    expect(resolveScenario(null, storage)).toBe('no-album');
    storage.setItem('archive-demo-user-scenario', 'invalid');
    expect(resolveScenario(null, storage)).toBe('main');
  });
});
