import { afterEach, describe, expect, it, vi } from 'vitest';
import catalog from '../backend/fixtures/progress-copies.v2.json';
import { GenerationPresentationStore, generationReadyAt, presentationFinished, projectGeneration, scheduleGeneration, selectGenerationTheme } from '../frontend/src/domain/generation';
import { MockArchiveService, type StorageLike } from '../frontend/src/services/mock';
import { createScenarioSettings } from '../frontend/src/fixtures/library';

const now = 1_800_000_000_000;
const stageIds = ['analyze_notes', 'understand_albums', 'generate_groups', 'review_suggestions'];
function memory(): StorageLike {
  const values = new Map<string, string>();
  return { getItem: key => values.get(key) ?? null, setItem: (key, value) => { values.set(key, value); } };
}
afterEach(() => vi.useRealTimers());

describe('前端四阶段等待展示与歌手文案库', () => {
  it('完整导入11位歌手、22组、88条文案，组内阶段和歌曲固定且不重复', () => {
    expect(catalog.version).toBe('V2'); expect(catalog.singers).toHaveLength(11);
    expect(catalog.singers.flatMap(singer => singer.groups.flatMap(group => group.stages))).toHaveLength(88);
    for (const singer of catalog.singers) {
      expect(singer.groups.map(group => group.id)).toEqual(['A', 'B']);
      expect(new Set(singer.groups.flatMap(group => group.stages.map(stage => stage.sourceSong))).size).toBe(8);
      for (const group of singer.groups) {
        expect(group.stages.map(stage => stage.id)).toEqual(stageIds);
        for (const stage of group.stages) {
          expect([...stage.copyText].length).toBeLessThanOrEqual(8);
          expect(stage.copyText).toContain(stage.sourceSong);
          expect([...stage.sourceSong].length).toBeLessThanOrEqual(8);
        }
      }
    }
  });
  it('新任务分别随机选歌手和组别，同一轮重复获取不重新抽取', () => {
    let calls = 0;
    const store = new GenerationPresentationStore(memory(), 'main', () => calls++ < 6 ? 0 : 0.999999);
    const first = store.getOrCreate('task-1', 'round-1', 53, true, now);
    expect(first.singerName).toBe('五月天'); expect(first.copyGroupId).toBe('A'); expect(calls).toBe(6);
    expect(store.getOrCreate('task-1', 'round-1', 53, true, now + 1000)).toEqual(first);
    expect(calls).toBe(6);
    const another = store.getOrCreate('task-2', 'round-1', 53, true, now);
    expect(another.singerName).toBe('单依纯'); expect(another.copyGroupId).toBe('B'); expect(calls).toBe(12);
  });
  it('每段随机1.5至2秒，整体6至8秒；等待结果时百分比最多99%', () => {
    const theme = selectGenerationTheme(() => 0);
    const fast = scheduleGeneration(theme, 53, true, now, () => 0);
    const slow = scheduleGeneration(theme, 53, true, now, () => 0.999999);
    expect(fast.stages.map(stage => stage.durationMs)).toEqual([1500, 1500, 1500, 1500]);
    expect(slow.stages.map(stage => stage.durationMs)).toEqual([2000, 2000, 2000, 2000]);
    expect(generationReadyAt(fast) - now).toBe(6000); expect(generationReadyAt(slow) - now).toBe(8000);
    expect(projectGeneration(fast, now - 1).percent).toBe(0);
    expect(projectGeneration(fast, now + 6000).percent).toBe(99);
  });
  it('精确切换四段文案，完整展示前不放行已提前生成的建议', () => {
    const progress = scheduleGeneration(selectGenerationTheme(() => 0), 53, true, now, () => 0);
    for (const [elapsed, stage] of [[0, 0], [1499, 0], [1500, 1], [2999, 1], [3000, 2], [4500, 3], [5999, 3]]) {
      expect(projectGeneration(progress, now + elapsed).currentStage).toBe(stage);
      expect(presentationFinished(progress, now + elapsed)).toBe(false);
    }
    expect(presentationFinished(progress, now + 6000)).toBe(true);
  });
  it('刷新重建展示存储后恢复同一时间线和文案，不重抽或从头播放', () => {
    const storage = memory();
    const original = new GenerationPresentationStore(storage, 'main', () => 0).getOrCreate('task', 'round', 53, true, now);
    const restored = new GenerationPresentationStore(storage, 'main', () => { throw new Error('不应重新抽取'); });
    const current = restored.getOrCreate('task', 'round', 53, true, now + 3200);
    expect(current).toEqual(original);
    expect(projectGeneration(current, now + 3200).currentStage).toBe(2);
    expect(presentationFinished(current, now + 8000)).toBe(true);
  });
  it('同任务后续轮次沿用歌手和组别，重新采样时长并使用本轮篇数', () => {
    let value = 0;
    const store = new GenerationPresentationStore(memory(), 'main', () => value);
    const first = store.getOrCreate('task', 'round-1', 53, true, now);
    value = 0.999999;
    const next = store.getOrCreate('task', 'round-2', 11, true, now + 6000);
    expect(next.singerId).toBe(first.singerId); expect(next.copyGroupId).toBe(first.copyGroupId);
    expect(next.stages.map(stage => stage.songId)).toEqual(first.stages.map(stage => stage.songId));
    expect(next.stages[0].label).toBe('正在分析11篇笔记'); expect(next.startedAt).toBe(now + 6000);
    expect(next.stages.every(stage => stage.durationMs === 2000)).toBe(true);
  });
  it('无专辑第二步梳理分类方向，使用歌名且不修改原始主题文案', () => {
    const theme = selectGenerationTheme(() => 0);
    const progress = scheduleGeneration(theme, 59, false, now, () => 0);
    expect(progress.stages[0].label).toBe('正在分析59篇笔记');
    expect(progress.stages[1].label).toBe('正在梳理分类方向'); expect(progress.stages[1].copyText).toBe('任意门');
    expect(theme.stages[1].copyText).toBe('打开专辑任意门');
  });
  it('展示延时独立于mock服务，建议可先就绪，等待中取消仍不归档', async () => {
    vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(now);
    const service = new MockArchiveService(memory());
    const library = await service.getLibrary();
    const round = await service.startTask(createScenarioSettings('main', library));
    const progress = new GenerationPresentationStore(memory(), 'main', () => 0).getOrCreate(round.taskId, round.id, 53, true, now);
    vi.setSystemTime(now + 1500);
    expect((await service.getRound(round.taskId, round.id)).status).toBe('preview');
    expect(presentationFinished(progress)).toBe(false);
    expect(round).not.toHaveProperty('generation');
    await service.cancelRound(round.taskId, round.id);
    expect((await service.getRound(round.taskId, round.id)).status).toBe('cancelled');
    expect(await service.getLibrary()).toEqual(library);
  });
  it('展示存储按情景隔离，重置仅清除本情景的主题与等待记录', () => {
    const storage = memory();
    const first = new GenerationPresentationStore(storage, 'main', () => 0);
    const second = new GenerationPresentationStore(storage, 'no-album', () => 0.999999);
    first.getOrCreate('task', 'round', 53, true, now);
    const preserved = second.getOrCreate('task', 'round', 59, false, now);
    first.reset();
    expect(new GenerationPresentationStore(storage, 'main').get('task', 'round')).toBeNull();
    expect(new GenerationPresentationStore(storage, 'no-album').get('task', 'round')).toEqual(preserved);
  });
  it('旧任务没有展示记录时返回空，不给已经打开的预览强制补播', () => {
    const store = new GenerationPresentationStore(memory(), 'main', () => { throw new Error('不应抽取'); });
    expect(store.get('old-task', 'old-round')).toBeNull();
  });
});
