import { describe, expect, it } from 'vitest';
import { MockArchiveService, type StorageLike } from '../frontend/src/services/mock';
import { createScenarioSettings } from '../frontend/src/fixtures/library';
import type { FeedbackReason, Scenario } from '../contracts/archive';

function memory(): StorageLike {
  const values = new Map<string, string>();
  return { getItem: key => values.get(key) ?? null, setItem: (key, value) => { values.set(key, value); } };
}
const request = { idempotencyKey: 'feedback-test', confirmedPublicAlbumIds: [] as string[] };
async function completed(storage: StorageLike = memory(), scenario: Scenario = 'main') {
  const service = new MockArchiveService(storage, scenario, 0);
  const round = await service.startTask(createScenarioSettings(scenario, await service.getLibrary()));
  await service.getRound(round.taskId, round.id);
  const result = await service.applyRound(round.taskId, round.id, request);
  return { service, round, result, storage };
}

describe('首次归类评分与进一步反馈', () => {
  it('生成或预览尚未写入时不发起评分，零写入也不发起', async () => {
    const service = new MockArchiveService(memory(), 'main', 0);
    const round = await service.startTask(createScenarioSettings('main', await service.getLibrary()));
    expect(await service.offerFeedback(round.taskId)).toBeNull();
    await service.getRound(round.taskId, round.id);
    expect(await service.offerFeedback(round.taskId)).toBeNull();
    await service.cancelRound(round.taskId, round.id);
    expect(await service.offerFeedback(round.taskId)).toBeNull();
    const zero = await completed(memory(), 'zero');
    expect(zero.result.archivedCount).toBe(0);
    expect(await zero.service.offerFeedback(zero.round.taskId)).toBeNull();
    await expect(service.offerFeedback('missing')).rejects.toThrow('任务不存在');
  });
  it('主动完成流程才发起调查，同一或后续任务、刷新后均不重复打扰', async () => {
    const { service, round, storage } = await completed();
    expect(await service.getFeedback()).toBeNull();
    const offered = await service.offerFeedback(round.taskId);
    expect(offered?.taskId).toBe(round.taskId);
    expect(offered?.rating).toBeNull();
    expect(await service.offerFeedback(round.taskId)).toBeNull();
    const restored = new MockArchiveService(storage, 'main', 0);
    expect(await restored.getFeedback()).toEqual(offered);
    expect(await restored.offerFeedback(round.taskId)).toBeNull();
    const next = await restored.nextRound(round.taskId, round.id);
    await restored.getRound(next.taskId, next.id);
    await restored.applyRound(next.taskId, next.id, request);
    expect(await restored.offerFeedback(next.taskId)).toBeNull();
    const another = await completed(storage);
    expect(await another.service.offerFeedback(another.round.taskId)).toBeNull();
  });
  it('多轮完成可按整次任务已有的成功写入发起，未归类5篇仍可评价', async () => {
    const { service, round } = await completed();
    const next = await service.nextRound(round.taskId, round.id);
    await service.getRound(next.taskId, next.id);
    await service.applyRound(next.taskId, next.id, request);
    expect(await service.getFeedback()).toBeNull();
    expect((await service.offerFeedback(round.taskId))?.taskId).toBe(round.taskId);
  });
  it('评分限定1至5的整数，重复操作保留首个评分并独立持久化', async () => {
    const { service, round, storage } = await completed();
    await expect(service.rateFeedback(4)).rejects.toThrow('先完成');
    await service.offerFeedback(round.taskId);
    for (const rating of [0, 6, 2.5, NaN]) await expect(service.rateFeedback(rating)).rejects.toThrow('1至5');
    await expect(service.submitFeedback({ reasons: ['inaccurate'], comment: '' })).rejects.toThrow('先为此次归类评分');
    const rated = await service.rateFeedback(4);
    expect(rated.rating).toBe(4); expect(rated.ratedAt).not.toBeNull(); expect(rated.submittedAt).toBeNull();
    expect(await service.rateFeedback(1)).toEqual(rated);
    expect(await new MockArchiveService(storage, 'main', 0).getFeedback()).toEqual(rated);
  });
  it('进一步反馈校验、去重、去除首尾空白并幂等提交，失败不覆盖评分', async () => {
    const { service, round, storage } = await completed();
    await service.offerFeedback(round.taskId); await service.rateFeedback(2);
    await expect(service.submitFeedback({ reasons: [], comment: '   ' })).rejects.toThrow('反馈方向');
    await expect(service.submitFeedback({ reasons: ['invalid' as FeedbackReason], comment: '' })).rejects.toThrow('对应');
    await expect(service.submitFeedback({ reasons: [], comment: '字'.repeat(301) })).rejects.toThrow('300');
    expect((await service.getFeedback())?.rating).toBe(2);
    const saved = await service.submitFeedback({ reasons: ['inaccurate', 'inaccurate', 'unclear_names'], comment: '  吉他谱想单独放一个专辑  ' });
    expect(saved.reasons).toEqual(['inaccurate', 'unclear_names']);
    expect(saved.comment).toBe('吉他谱想单独放一个专辑');
    expect(saved.submittedAt).not.toBeNull();
    expect(await service.submitFeedback({ reasons: ['other'], comment: '重复提交' })).toEqual(saved);
    expect(await new MockArchiveService(storage, 'main', 0).getFeedback()).toEqual(saved);
  });
  it('情景隔离，重置清除当前评分和反馈并允许重新体验', async () => {
    const storage = memory();
    const first = await completed(storage, 'main');
    const second = await completed(storage, 'no-album');
    await first.service.offerFeedback(first.round.taskId); await first.service.rateFeedback(5);
    await second.service.offerFeedback(second.round.taskId); await second.service.rateFeedback(3);
    first.service.reset();
    expect(await first.service.getFeedback()).toBeNull();
    expect((await new MockArchiveService(storage, 'no-album', 0).getFeedback())?.rating).toBe(3);
    const restarted = await completed(storage, 'main');
    expect(await restarted.service.offerFeedback(restarted.round.taskId)).not.toBeNull();
  });
  it.each([1, 3, 4, 5])('%s星仅接收该星级组的反馈原因', async rating => {
    const { service, round } = await completed();
    await service.offerFeedback(round.taskId); await service.rateFeedback(rating);
    const expected = rating <= 3 ? 'inaccurate' : 'accurate';
    const opposite = rating <= 3 ? 'accurate' : 'inaccurate';
    await expect(service.submitFeedback({ reasons: [opposite], comment: '' })).rejects.toThrow('对应');
    const saved = await service.submitFeedback({ reasons: [expected, 'other'], comment: '' });
    expect(saved.rating).toBe(rating);
    expect(saved.reasons).toEqual([expected, 'other']);
  });
});
