import { describe, expect, it } from 'vitest';
import { buildRound, canOfferNextRound, DAY, eligible, inRange, moveNotes, plannedCount, publicTargets, unfiled } from '../frontend/src/domain/rules';
import { createLibrary, createScenarioSettings } from '../frontend/src/fixtures/library';
import { MockArchiveService, type StorageLike } from '../frontend/src/services/mock';
import type { Scenario } from '../contracts/archive';

const now = 1_800_000_000_000;
function memory(): StorageLike { const values = new Map<string, string>(); return { getItem: k => values.get(k) ?? null, setItem: (k, v) => { values.set(k, v); } }; }
async function preview(scenario: Scenario = 'main', allowNew?: boolean) {
  const storage = memory(); const service = new MockArchiveService(storage, scenario, 0);
  const library = await service.getLibrary(); const settings = createScenarioSettings(scenario, library);
  const started = await service.startTask({ ...settings, allowNew: allowNew ?? settings.allowNew });
  const round = await service.getRound(started.taskId, started.id); return { service, library, round, storage };
}
const request = { idempotencyKey: 'test-key', confirmedPublicAlbumIds: [] as string[] };

describe('资格、范围与生成规则', () => {
  it('覆盖无体系、久未维护与不合格用户', () => {
    expect(eligible(createLibrary('no-album', now), now)).toBe(true);
    expect(eligible(createLibrary('main', now), now)).toBe(true);
    expect(eligible(createLibrary('ineligible', now), now)).toBe(false);
    const recent = createLibrary('main', now); recent.profile.lastMaintainedAt = now;
    expect(eligible(recent, now)).toBe(false);
  });
  it('收藏50篇、未归档30篇与未维护7天均包含边界', () => {
    const library = createLibrary('main', now);
    library.notes = library.notes.slice(0, 50);
    library.notes.forEach((note, index) => { note.albumIds = index < 30 ? [] : ['album-guitar']; });
    library.profile.lastMaintainedAt = now - 7 * DAY;
    expect(eligible(library, now)).toBe(true);
    library.profile.lastMaintainedAt += 1;
    expect(eligible(library, now)).toBe(false);
    library.profile.lastMaintainedAt -= 1;
    library.notes[0].albumIds = ['album-guitar'];
    expect(eligible(library, now)).toBe(false);
    library.notes[0].albumIds = [];
    library.notes.pop();
    expect(eligible(library, now)).toBe(false);
    const noAlbum = createLibrary('no-album', now);
    noAlbum.notes = noAlbum.notes.slice(0, 50);
    expect(eligible(noAlbum, now)).toBe(true);
    noAlbum.notes.pop();
    expect(eligible(noAlbum, now)).toBe(false);
  });
  it('近期未整理的初始维护时间为8天前', () => {
    expect(createLibrary('main', now).profile.lastMaintainedAt).toBe(now - 8 * DAY);
  });
  it('按真实数据筛选：未归档53篇无50篇上限，近30天32篇', () => {
    const library = createLibrary('main', now);
    expect(library.notes).toHaveLength(59); expect(unfiled(library)).toHaveLength(53);
    expect(inRange(unfiled(library), null, now)).toHaveLength(53);
    expect(inRange(unfiled(library), 30, now)).toHaveLength(32);
  });
  it('天数按24小时计算，包含边界，不包含未来', () => {
    const note = createLibrary('main', now).notes[0];
    expect(inRange([{ ...note, collectedAt: now - DAY }, { ...note, collectedAt: now - DAY - 1 }, { ...note, collectedAt: now + 1 }], 1, now)).toHaveLength(1);
    expect(() => inRange([note], 0, now)).toThrow(); expect(() => inRange([note], 2.5, now)).toThrow();
  });
  it('新组3篇不建议、4篇可建议；已有专辑1篇可承接', () => {
    const library = createLibrary('main', now); const photos = library.notes.filter(n => n.topic === 'photography').slice(0, 4).map(n => n.id);
    expect(buildRound(library, photos.slice(0, 3), true, 't', 1).groups).toHaveLength(0);
    expect(buildRound(library, photos, true, 't', 1).groups).toHaveLength(1);
    const guitar = unfiled(library).find(n => n.topic === 'guitar')!;
    expect(buildRound(library, [guitar.id], false, 't', 1).groups[0].noteIds).toHaveLength(1);
  });
  it('首轮含已有吉他与5个新组：42篇建议，11篇未归类', async () => {
    const { round } = await preview(); expect(round.groups).toHaveLength(6);
    expect(round.groups.filter(g => g.isNew)).toHaveLength(5); expect(plannedCount(round)).toBe(42);
    expect(round.unclassifiedIds).toHaveLength(11); expect(round.canContinue).toBe(true);
  });
  it('关闭新建仅匹配8篇，隐藏45篇，无未归类区域', async () => {
    const { round } = await preview('existing'); expect(plannedCount(round)).toBe(8);
    expect(round.unclassifiedIds).toHaveLength(0); expect(round.hiddenCount).toBe(45); expect(round.canContinue).toBe(false);
  });
  it('5个候选新组不询问，6个候选才询问，已有组不占名额', async () => {
    const five = await preview('five'); const six = await preview('overflow');
    expect(five.round.candidateCount).toBe(5); expect(five.round.canContinue).toBe(false);
    expect(six.round.candidateCount).toBe(6); expect(six.round.groups.filter(g => g.isNew)).toHaveLength(5);
    expect(six.round.groups.find(g => g.id === 'album-guitar')?.isNew).toBe(false);
  });
  it('相同篇数按最近收藏选择候选，同名复用而不重复建议', () => {
    const library = createLibrary('main', now);
    const outfit = library.notes.filter(n => n.topic === 'outfit'); outfit.forEach(n => { n.collectedAt = now; });
    const round = buildRound(library, unfiled(library).map(n => n.id), true, 't', 1);
    expect(round.groups.some(g => g.name === '穿搭')).toBe(true);
    expect(round.groups.filter(g => g.name === '吉他')).toHaveLength(1);
  });
  it('不可访问与信息不足不被强制归类', async () => {
    const { round, library } = await preview(); const assigned = round.groups.flatMap(g => g.noteIds);
    expect(library.notes.filter(n => !n.accessible || n.topic === 'misc').every(n => !assigned.includes(n.id))).toBe(true);
  });
});

describe('预览调整、取消、确认与轮次', () => {
  it.each([['main', true], ['no-album', true], ['five', false], ['existing', false], ['zero', false]] as const)('%s仅在本轮归档成功且允许新建、超出5个新分类时提示继续', async (scenario, expected) => {
    const { service, round } = await preview(scenario);
    const result = await service.applyRound(round.taskId, round.id, request);
    const library = await service.getLibrary();
    const applied = await service.getRound(round.taskId, round.id);
    expect(canOfferNextRound(round, result, library)).toBe(false);
    expect(canOfferNextRound(applied, result, library)).toBe(expected);
    expect(canOfferNextRound({ ...applied, allowNew: false, canContinue: true }, result, library)).toBe(false);
    if (scenario === 'no-album') expect(result.unclassifiedCount).toBe(17);
    if (scenario === 'main') expect(result.unclassifiedCount).toBe(11);
  });
  it('用户跳过全部可处理的剩余笔记时不再提示继续', async () => {
    const { service, round, library } = await preview();
    const accessible = new Set(library.notes.filter(note => note.accessible).map(note => note.id));
    await service.adjustRound(round.taskId, round.id, round.unclassifiedIds.filter(id => accessible.has(id)), null);
    const result = await service.applyRound(round.taskId, round.id, request);
    const applied = await service.getRound(round.taskId, round.id);
    expect(result.unclassifiedCount).toBeGreaterThan(0);
    expect(canOfferNextRound(applied, result, await service.getLibrary())).toBe(false);
  });
  it('情景分别保存进度，重置仅清除当前情景的收藏修改、提醒、任务与结果', async () => {
    const storage = memory();
    const first = new MockArchiveService(storage, 'no-album', 0);
    await first.createAlbum('独立情景专辑');
    const other = new MockArchiveService(storage, 'main', 0);
    const started = await other.startTask(createScenarioSettings('main', await other.getLibrary()));
    await other.getRound(started.taskId, started.id);
    await other.applyRound(started.taskId, started.id, request);
    await other.markReminderSeen();
    const saved = new MockArchiveService(storage, 'main', 0);
    expect(unfiled(await saved.getLibrary())).toHaveLength(11);
    expect(eligible(await saved.getLibrary(), Date.now())).toBe(false);
    expect((await new MockArchiveService(storage, 'no-album', 0).getLibrary()).albums[0].name).toBe('独立情景专辑');
    saved.reset();
    const reset = new MockArchiveService(storage, 'main', 0);
    const library = await reset.getLibrary();
    expect(unfiled(library)).toHaveLength(53);
    expect(library.albums).toHaveLength(1);
    expect(library.profile.reminderSeen).toBe(false);
    expect(eligible(library, Date.now())).toBe(true);
    await expect(reset.getRound(started.taskId, started.id)).rejects.toThrow('任务不存在');
    await expect(reset.applyRound(started.taskId, started.id, request)).rejects.toThrow('任务不存在');
    const preserved = await new MockArchiveService(storage, 'no-album', 0).getLibrary();
    expect(preserved.albums[0].name).toBe('独立情景专辑');
    expect(unfiled(preserved)).toHaveLength(59);
  });
  it('创建专辑后更新维护时间，不再满足未维护提醒条件', async () => {
    const service = new MockArchiveService(memory(), 'main', 0);
    expect(eligible(await service.getLibrary(), Date.now())).toBe(true);
    await service.createAlbum('新专辑');
    expect(eligible(await service.getLibrary(), Date.now())).toBe(false);
  });
  it('生成、预览与取消都不新增专辑或写归属', async () => {
    const { service, round } = await preview(); await service.cancelRound(round.taskId, round.id);
    const library = await service.getLibrary(); expect(library.albums).toHaveLength(1); expect(unfiled(library)).toHaveLength(53);
    await expect(service.applyRound(round.taskId, round.id, request)).rejects.toThrow();
  });
  it('批量纠正保留真实主题，确认后数据反映调整', async () => {
    const { service, round } = await preview('correction');
    const ids = ['note-guitar-07', 'note-guitar-08'];
    const updated = await service.adjustRound(round.taskId, round.id, ids, 'album-guitar');
    expect(updated.groups.find(g => g.id === 'album-guitar')?.noteIds).toHaveLength(8);
    expect(updated.groups.find(g => g.name === '摄影')?.noteIds).toHaveLength(6);
    await service.applyRound(round.taskId, round.id, request); const library = await service.getLibrary();
    expect(library.notes.filter(n => ids.includes(n.id)).every(n => n.albumIds.includes('album-guitar') && n.topic === 'guitar')).toBe(true);
  });
  it('人工移走后建议即使剩3篇仍保留，顺序与K不变', async () => {
    const { service, round } = await preview(); const group = round.groups.find(g => g.name === '家居')!;
    const updated = await service.adjustRound(round.taskId, round.id, group.noteIds.slice(0, 3), 'album-guitar');
    expect(updated.groups.find(g => g.id === group.id)?.noteIds).toHaveLength(3);
    expect(updated.groups.map(g => g.id)).toEqual(round.groups.map(g => g.id)); expect(updated.candidateCount).toBe(6);
    await service.applyRound(round.taskId, round.id, request); const library = await service.getLibrary();
    const album = library.albums.find(a => a.name === group.name)!;
    expect(library.notes.filter(n => n.albumIds.includes(album.id))).toHaveLength(3);
  });
  it('空组保留预览，确认时不创建空专辑', async () => {
    const { service, round } = await preview(); const group = round.groups.find(g => g.isNew)!;
    const updated = await service.adjustRound(round.taskId, round.id, group.noteIds, null);
    expect(updated.groups.find(g => g.id === group.id)?.noteIds).toHaveLength(0);
    await service.applyRound(round.taskId, round.id, request);
    expect((await service.getLibrary()).albums.some(a => a.name === group.name)).toBe(false);
  });
  it('公开专辑必须明确确认，未确认时所有归属保持原样', async () => {
    const { service, round } = await preview('public', false);
    await expect(service.applyRound(round.taskId, round.id, request)).rejects.toThrow('公开');
    expect(unfiled(await service.getLibrary())).toHaveLength(53);
    const result = await service.applyRound(round.taskId, round.id, { ...request, confirmedPublicAlbumIds: publicTargets(round).map(g => g.id) });
    expect([result.archivedCount, result.unclassifiedCount]).toEqual([8, 45]);
  });
  it('重复提交、更换幂等键与重建客户端均不重复创建或计数', async () => {
    const { service, round, storage } = await preview();
    const first = await service.applyRound(round.taskId, round.id, request);
    const second = await service.applyRound(round.taskId, round.id, { ...request, idempotencyKey: 'other' });
    const restored = new MockArchiveService(storage, 'main', 0);
    expect(await restored.applyRound(round.taskId, round.id, request)).toEqual(first); expect(second).toEqual(first);
    const library = await restored.getLibrary(); expect(library.albums).toHaveLength(6); expect(unfiled(library)).toHaveLength(11);
    expect(library.albums.every(a => a.visibility === 'private')).toBe(true);
  });
  it.each([['partial', 41, 12], ['zero', 0, 53]] as const)('%s按实际写入计数', async (scenario, x, y) => {
    const { service, round } = await preview(scenario); const result = await service.applyRound(round.taskId, round.id, request);
    expect([result.archivedCount, result.unclassifiedCount]).toEqual([x, y]);
    expect(unfiled(await service.getLibrary())).toHaveLength(53 - x);
  });
  it('先确认本轮，才继续同任务下一轮，排除已归档项', async () => {
    const { service, round } = await preview(); await expect(service.nextRound(round.taskId, round.id)).rejects.toThrow();
    const result = await service.applyRound(round.taskId, round.id, request); const next = await service.nextRound(round.taskId, round.id);
    expect(next.taskId).toBe(round.taskId); expect(next.number).toBe(2); expect(next.noteIds).toHaveLength(11);
    expect(next.noteIds.some(id => result.archivedIds.includes(id))).toBe(false); expect(await service.nextRound(round.taskId, round.id)).toEqual(next);
    const ready = await service.getRound(next.taskId, next.id); expect(plannedCount(ready)).toBe(6);
    const second = await service.applyRound(next.taskId, next.id, request); expect(second.unclassifiedCount).toBe(5);
    expect(unfiled(await service.getLibrary())).toHaveLength(5);
  });
  it('主动跳过的未归类项不进入下一轮', async () => {
    const { service, round } = await preview(); const id = round.unclassifiedIds[0];
    await service.adjustRound(round.taskId, round.id, [id], null); await service.applyRound(round.taskId, round.id, request);
    expect((await service.nextRound(round.taskId, round.id)).noteIds).not.toContain(id);
  });
  it('拒绝未知目的地、不可访问项和重复noteId', async () => {
    const { round, library } = await preview(); const id = round.groups[0].noteIds[0];
    expect(() => moveNotes(round, [id], 'missing', library)).toThrow();
    expect(() => moveNotes(round, [library.notes.find(n => !n.accessible)!.id], 'album-guitar', library)).toThrow();
    const destination = round.groups.find(g => g.isNew)!;
    const updated = moveNotes(round, [id, id], destination.id, library);
    expect(updated.groups.find(g => g.id === destination.id)!.noteIds.filter(n => n === id)).toHaveLength(1);
  });
  it('无匹配空态、空选择与无已有专辑关闭新建的禁用条件', async () => {
    const { round } = await preview('empty'); expect(round.groups).toHaveLength(0); expect(round.hiddenCount).toBe(45);
    const service = new MockArchiveService(memory(), 'no-album', 0);
    await expect(service.startTask({ noteIds: [], allowNew: true, rangeLabel: '全部' })).rejects.toThrow();
    const library = await service.getLibrary();
    await expect(service.startTask({ noteIds: [library.notes[0].id], allowNew: false, rangeLabel: '全部' })).rejects.toThrow();
  });
  it('提醒状态持久化；生成异常保留笔记快照与原始归属', async () => {
    const { service, storage, round } = await preview('error'); await service.markReminderSeen();
    expect((await new MockArchiveService(storage, 'error', 0).getLibrary()).profile.reminderSeen).toBe(true);
    expect(round.status).toBe('error'); expect(round.noteIds).toHaveLength(53); expect(unfiled(await service.getLibrary())).toHaveLength(53);
  });
  it('运行中新增的收藏不进入已固定的任务快照', async () => {
    const { storage, round } = await preview(); const key = 'archive-demo-uploaded-v2:main';
    const saved = JSON.parse(storage.getItem(key)!); const sample = saved.library.notes.find((n: { albumIds: string[] }) => !n.albumIds.length);
    saved.library.notes.push({ ...sample, id: 'new-note', collectedAt: Date.now() }); storage.setItem(key, JSON.stringify(saved));
    const restored = new MockArchiveService(storage, 'main', 0); await restored.applyRound(round.taskId, round.id, request);
    expect((await restored.nextRound(round.taskId, round.id)).noteIds).not.toContain('new-note');
    expect((await restored.getLibrary()).notes.find(n => n.id === 'new-note')?.albumIds).toHaveLength(0);
  });
});
