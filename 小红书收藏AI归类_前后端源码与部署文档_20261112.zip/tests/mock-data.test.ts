import { describe, expect, it } from 'vitest';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { createBoundarySelections, createLibrary, createScenarioSettings } from '../frontend/src/fixtures/library';
import manifest from '../frontend/src/fixtures/assets.manifest.json';
import { buildRound, DAY, eligible, inRange, moveNotes, plannedCount, unfiled } from '../frontend/src/domain/rules';
import { MockArchiveService } from '../frontend/src/services/mock';
import type { Scenario } from '../contracts/archive';

const now = Date.parse('2026-11-12T20:00:00+08:00');
function service(scenario: Scenario = 'main') {
  const storage = new Map<string, string>();
  return new MockArchiveService({ getItem: key => storage.get(key) ?? null, setItem: (key, value) => { storage.set(key, value); } }, scenario, 0);
}
async function preview(s: MockArchiveService, scenario: Scenario = 'main') {
  const library = await s.getLibrary();
  const round = await s.startTask(createScenarioSettings(scenario, library));
  return s.getRound(round.taskId, round.id);
}
const request = { idempotencyKey: 'test-apply', confirmedPublicAlbumIds: [] as string[] };

describe('uploaded mock library', () => {
  it('uses all 59 original covers, with one existing guitar album and 53 unfiled notes', () => {
    const library = createLibrary('main', now);
    expect(library.notes).toHaveLength(59);
    expect(library.albums).toEqual([{ id: 'album-guitar', name: '吉他', visibility: 'private' }]);
    expect(library.notes.filter(n => n.albumIds.includes('album-guitar'))).toHaveLength(6);
    expect(unfiled(library)).toHaveLength(53);
    expect(unfiled(library).filter(n => n.topic === 'guitar')).toHaveLength(8);
    expect(eligible(library, now)).toBe(true);
    expect(eligible(createLibrary('ineligible', now), now)).toBe(false);
    expect(new Set(library.notes.map(n => n.cover)).size).toBe(59);
    for (const asset of manifest) {
      const path = resolve('frontend/public', asset.cover);
      expect(existsSync(path), asset.cover).toBe(true);
      expect(createHash('sha256').update(readFileSync(path)).digest('hex')).toBe(asset.sha256);
    }
    const unavailable = library.notes.find(n => !n.accessible)!;
    expect(unavailable.body).toBe('');
    expect(unavailable.tags).toEqual([]);
  });
  it('has useful time ranges and includes exact N-day boundaries', () => {
    const notes = unfiled(createLibrary('main', now));
    const counts = [7,30,90].map(days => inRange(notes, days, now).length);
    expect(counts).toEqual([14,32,43]);
    expect(counts[0]).toBeGreaterThan(0);
    expect(counts[0]).toBeLessThan(counts[1]);
    expect(counts[1]).toBeLessThan(counts[2]);
    expect(counts[2]).toBeLessThan(53);
    expect(inRange(notes, 7, now).some(n => n.collectedAt === now - 7 * DAY)).toBe(true);
    expect(inRange(notes, 1, now + 400 * DAY)).toHaveLength(0);
    expect(() => inRange(notes, 0, now)).toThrow();
  });
  it('covers 3/4 thresholds, existing albums below 4, K<5, K=5, and K>5', () => {
    const library = createLibrary('main', now);
    const scopes = createBoundarySelections(library);
    const round = (ids: string[]) => buildRound(library, ids, true, 'boundaries', 1);
    expect(round(scopes.newGroupThree).groups).toHaveLength(0);
    const four = round(scopes.newGroupFour);
    expect(plannedCount(four)).toBe(4);
    expect(round(scopes.existingOneNote).groups[0].isNew).toBe(false);
    expect(round(scopes.fewerThanFiveGroups).candidateCount).toBe(4);
    expect(round(scopes.exactFiveGroups).canContinue).toBe(false);
    const five = createLibrary('five', now);
    expect(buildRound(five, unfiled(five).map(n => n.id), true, 'five', 1).candidateCount).toBe(5);
    const full = round(unfiled(library).map(n => n.id));
    expect(full.candidateCount).toBe(6);
    expect(full.groups.filter(g => g.isNew)).toHaveLength(5);
    expect(full.canContinue).toBe(true);
    expect(plannedCount(full)).toBe(42);
    expect(full.unclassifiedIds).toHaveLength(11);
  });
  it('preserves a suggested album after moving notes below the four-note threshold', () => {
    const library = createLibrary('main', now);
    const ids = createBoundarySelections(library).newGroupFour;
    const round = buildRound(library, ids, true, 'manual', 1); round.status = 'preview';
    const adjusted = moveNotes(round, [ids[0]], 'album-guitar', library);
    expect(adjusted.groups.find(g => g.isNew)?.noteIds).toHaveLength(3);
    const empty = moveNotes(adjusted, ids.slice(1), null, library);
    expect(empty.groups.find(g => g.isNew)?.noteIds).toHaveLength(0);
  });
});

describe('mock archive scenarios', () => {
  it('commits two rounds separately, preserves the original six notes, and is idempotent', async () => {
    const s = service(); const round = await preview(s);
    expect((await s.getLibrary()).albums).toHaveLength(1);
    await expect(s.nextRound(round.taskId, round.id)).rejects.toThrow();
    const first = await s.applyRound(round.taskId, round.id, request);
    expect([first.archivedCount, first.unclassifiedCount]).toEqual([42,11]);
    expect(await s.applyRound(round.taskId, round.id, { ...request, idempotencyKey: 'other' })).toEqual(first);
    const next = await s.nextRound(round.taskId, round.id);
    const ready = await s.getRound(next.taskId, next.id);
    expect(ready.groups.map(g => g.name)).toEqual(['穿搭']);
    const second = await s.applyRound(ready.taskId, ready.id, request);
    expect([second.archivedCount, second.unclassifiedCount]).toEqual([6,5]);
    const library = await s.getLibrary();
    expect(library.albums).toHaveLength(7);
    expect(library.notes.filter(n => n.albumIds.includes('album-guitar'))).toHaveLength(14);
    expect(unfiled(library)).toHaveLength(5);
  });
  it.each([['partial', 41, 12], ['zero', 0, 53]] as const)('%s counts only actual writes', async (scenario, archived, remaining) => {
    const s = service(scenario); const round = await preview(s, scenario);
    const result = await s.applyRound(round.taskId, round.id, request);
    expect([result.archivedCount, result.unclassifiedCount]).toEqual([archived, remaining]);
    const library = await s.getLibrary();
    expect(library.notes.filter(n => n.albumIds.length)).toHaveLength(6 + archived);
    if (!archived) expect(library.albums).toHaveLength(1);
  });
  it('matches only eight unfiled guitar notes when new albums are disabled', async () => {
    const s = service('existing'); const round = await preview(s, 'existing');
    expect(plannedCount(round)).toBe(8);
    expect(round.hiddenCount).toBe(45);
    expect(round.unclassifiedIds).toEqual([]);
    const result = await s.applyRound(round.taskId, round.id, request);
    expect([result.archivedCount, result.unclassifiedCount]).toEqual([8,45]);
    const e = service('empty'); const empty = await preview(e, 'empty');
    expect(empty.groups).toHaveLength(0);
    expect(empty.hiddenCount).toBe(45);
  });
  it('blocks a no-album disabled-new selection and requires public confirmation', async () => {
    const s = service('no-album'); const library = await s.getLibrary();
    expect(library.albums).toHaveLength(0);
    expect(unfiled(library)).toHaveLength(59);
    await expect(s.startTask({ ...createScenarioSettings('no-album', library), allowNew: false })).rejects.toThrow();
    await expect(s.startTask({ noteIds: [], allowNew: true, rangeLabel: '全部' })).rejects.toThrow();
    const p = service('public'); const round = await preview(p, 'public');
    await expect(p.applyRound(round.taskId, round.id, request)).rejects.toThrow('请先确认公开专辑');
    expect((await p.applyRound(round.taskId, round.id, { ...request, confirmedPublicAlbumIds: ['album-guitar'] })).archivedCount).toBe(42);
  });
  it('preserves data on failure/cancel and preserves real topics in the correction variant', async () => {
    const s = service('error'); const before = await s.getLibrary();
    const round = await preview(s, 'error'); expect(round.status).toBe('error');
    expect(await s.getLibrary()).toEqual(before);
    const c = service(); const cancelled = await c.startTask(createScenarioSettings('main', await c.getLibrary()));
    await c.cancelRound(cancelled.taskId, cancelled.id);
    await expect(c.applyRound(cancelled.taskId, cancelled.id, request)).rejects.toThrow();
    expect((await c.getLibrary()).albums).toHaveLength(1);
    const corrected = service('correction'); const correction = await preview(corrected, 'correction');
    expect(correction.groups.find(g => g.name === '吉他')?.noteIds).toHaveLength(6);
    const target = correction.groups.find(g => g.name === '吉他')!;
    const adjusted = await corrected.adjustRound(correction.taskId, correction.id, ['note-guitar-07','note-guitar-08'], target.id);
    expect(adjusted.groups.find(g => g.name === '吉他')?.noteIds).toHaveLength(8);
    expect(adjusted.groups.find(g => g.name === '摄影')?.noteIds).toHaveLength(6);
  });
});
