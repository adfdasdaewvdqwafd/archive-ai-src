# 部署说明（RedCoWork 交接版）

更新日期：2026-11-12。项目为 React + TypeScript + Vite 移动端 Web 应用，默认运行 Mock 模式。当前可上线完整交互演示；真实收藏读写、登录、数据库和模型服务需后续接入，详见 [接口文档](API.md)。

## 1. RedCoWork 适配范围

目标入口：[RedCoWork](https://redcowork.xiaohongshu.com/)。本次未上传、创建应用或执行平台上线。

本次公开资料核验未取得该站的源码 ZIP 格式、大小限制、Node 版本、包管理器、构建命令、端口及持久化规范。小红书公开的[小工具服务协议](https://agree.xiaohongshu.com/h5/terms/ZXXY20260630004/-1)说明了代码包上传、审核、构建和部署流程，并规定支持类型与技术规范以平台实际页面为准；该协议不能用于确认此站的具体运行参数。

下面提供本项目的标准部署入口。按登录后平台实际提供的功能，选择源码构建、静态托管或 Node 服务方式。Docker 用于支持容器的平台。

## 2. 解压与安装

ZIP 根层直接放置 package.json、frontend/、backend/，无需再切换到项目子目录。建议使用 Node.js 24（本次验证版本 v24.22.1），项目最低要求 Node.js 22.12，pnpm 固定为 11.25.0。

```bash
corepack enable
corepack prepare pnpm@11.25.0 --activate
pnpm install --frozen-lockfile
pnpm build
```

构建先检查 TypeScript，再将页面、脚本、样式和图片输出到 dist/。源码包保留锁文件；依赖目录、缓存及旧构建产物均在包外。

## 3. 平台配置表

以下是本项目配置值，平台是否提供对应输入项以实际界面为准。

| 项目 | 本项目的值 |
|---|---|
| 项目根目录 | 解压根目录（含 package.json） |
| 安装命令 | pnpm install --frozen-lockfile |
| 构建命令 | pnpm build |
| 静态产物目录 | dist |
| Node 启动命令 | node scripts/serve.mjs 或 pnpm start |
| Node 监听地址 | 0.0.0.0 |
| Node 端口 | 读取平台注入的 PORT，缺省 3000 |
| 健康检查 | GET /healthz，仅 Node 服务提供 |
| 数据模式 | VITE_DATA_MODE=mock |
| 资源路径 | VITE_BASE_PATH=./ |
| 页面路由 | Hash 路由，无需 SPA 路径回退 |

如平台只有对话和附件入口，可上传源码 ZIP 并粘贴 [RedCoWork 交接指令](REDCOWORK.md)。附件入口是否支持 ZIP 源码导入，须以平台实际规则为准。

## 4. 三种运行方式

### A. 源码构建与静态托管

按上表配置安装、构建与输出目录，构建变量使用 VITE_DATA_MODE=mock、VITE_BASE_PATH=./。发布后即可体验，数据保存在访问者浏览器中。

如果平台只接受构建结果，先在本地执行 pnpm build，随后上传 dist/ 内的全部文件；index.html 应位于托管入口根层。源码 ZIP 与静态产物是两种不同输入。

### B. Node 服务

构建完成后执行：

```bash
node scripts/serve.mjs
```

默认入口为 http://127.0.0.1:3000/，健康检查为 http://127.0.0.1:3000/healthz。运行阶段只需 dist/、scripts/serve.mjs 和 Node，无需生产依赖。此进程托管静态文件；/api/* 返回 501，提示尚未接入业务后端。

部署在 /archive/ 子路径时，运行变量设置 APP_BASE_PATH=/archive，构建变量保持 VITE_BASE_PATH=./；/archive 会重定向到 /archive/，健康检查仍为 /healthz。

### C. Docker

```bash
docker build -t collection-archive .
docker run --rm -p 3000:3000 -e PORT=3000 collection-archive
```

本次验证覆盖本地 Node 构建和服务；Docker 镜像未构建验证，RedCoWork 是否支持容器待平台确认。

## 5. 环境变量

| 变量 | 默认值 | 生效阶段 | 说明 |
|---|---|---|---|
| VITE_DATA_MODE | mock | 构建 | mock 为浏览器模拟服务；http 为真实业务接口 |
| VITE_API_BASE_URL | /api | 构建 | 推荐同源 /api |
| VITE_BASE_PATH | ./ | 构建 | Vite 静态资源路径 |
| API_PROXY_TARGET | 空 | 本地开发 | 如 http://127.0.0.1:3001，代理 /api；生产不生效 |
| HOST | 0.0.0.0 | Node 运行 | 监听地址 |
| PORT | 3000 | Node 运行 | 平台可注入端口 |
| APP_BASE_PATH | / | Node 运行 | 静态入口子路径 |

本地可将 .env.example 复制为 .env.local 后构建。VITE_* 会写入公开 JS，修改后必须重新构建。密钥放在未来业务后端的环境变量中。pnpm start 不自动加载 .env.local；运行变量在平台设置，本地可执行 node --env-file=.env.local scripts/serve.mjs。

## 6. 接入真实后端

1. 按 contracts/archive.ts 和 API.md 实现业务服务，完成登录用户隔离、收藏数据授权、模型任务、数据库持久化与归档事务。
2. 推荐由网关把同域 /api/* 转发至业务服务，其余路径托管 dist/。当前 scripts/serve.mjs 不提供生产 API 代理。
3. 构建时设置 VITE_DATA_MODE=http、VITE_API_BASE_URL=/api，重新构建并发布。服务失败会显示错误，不会降级为模拟成功。
4. 当前 HTTP 适配器使用 credentials: 'same-origin'，没有 Authorization 注入。跨域 Cookie 登录需额外修改凭据策略并配置 CORS、CSRF；仅填写外域 URL 不会携带登录 Cookie。
5. 真实版发布前验证用户隔离、公开专辑确认、重复归档幂等、取消与写入竞争、部分失败计数、每轮最多 5 个新专辑、跨设备持久化及模型失败处理。

## 7. 发布检查与排错

```bash
pnpm check
pnpm test
pnpm build
# 另一个终端启动 pnpm start 后运行：
node scripts/smoke.mjs http://127.0.0.1:3000/
```

浏览器验收：情景控制台、归类范围、四段等待、预览与调整、公开目标确认、归档结果、继续下一轮、评分反馈和刷新恢复。默认演示包含 59 张封面，保持随源码上传。

| 现象 | 检查方式 |
|---|---|
| 构建找不到 Vite/tsc | 安装时包含开发依赖，并执行锁定安装 |
| 页面或图片 404 | 检查产物目录为 dist，子路径与资源前缀一致 |
| /api/library 返回 501 | 当前为静态服务；演示用 mock 重新构建，真实版配置业务服务路由 |
| 修改模式后页面没变化 | VITE 变量在构建时生效，需要重新 build 和发布 |
| 其他浏览器没有原进度 | Mock 按浏览器保存；跨设备共享需真实后端 |
| pnpm 不可用 | 使用 packageManager 指定版本，并确认平台可访问对应包源 |

更新时保存当前可用源码 ZIP 与平台版本号。回退使用上一份源码重新构建，或使用平台提供的版本回滚能力。
