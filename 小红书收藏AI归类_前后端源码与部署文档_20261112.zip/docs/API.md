# 前后端接口文档 V1

本规范与HTTP适配器一致，是后续后端的接入目标；本阶段没有真实API服务。TypeScript模型见 `contracts/archive.ts`。

更新日期：2026-11-12。已实现部分为前端 `HttpArchiveService` 与浏览器 `MockArchiveService`；下文业务端点为待实现契约。现有 Node 静态服务仅实现 `GET /healthz`，返回 `{ "status": "ok", "service": "collection-archive-frontend" }`，业务 `/api/*` 返回 HTTP 501。

推荐同源 `/api`，JSON请求及JSON成功响应。服务端从认证会话确定用户身份，不信任前端传入的userId。HTTP错误响应使用 `{ "message": "可展示的错误信息", "code": "机器错误码" }`，配合合理状态码。无内容成功可返回204。

| 方法 | 相对API入口的路径 | 请求 | 成功响应 |
|---|---|---|---|
| GET | /library | — | Library |
| POST | /reminder/seen | {} | 204 |
| POST | /albums | {name,visibility:"private"} | Album |
| POST | /tasks | Settings：noteIds、allowNew、rangeLabel | Round，初始generating |
| GET | /tasks/:taskId/rounds/:roundId | — | Round |
| POST | /tasks/:taskId/rounds/:roundId/cancel | {} | 204 |
| POST | /tasks/:taskId/rounds/:roundId/adjust | {noteIds,destination:string或null} | 更新后的Round |
| POST | /tasks/:taskId/rounds/:roundId/apply | {idempotencyKey,confirmedPublicAlbumIds} | ApplyResult |
| POST | /tasks/:taskId/rounds/:roundId/next | {} | 下一轮Round，初始generating |
| POST | /events | {name,taskId?,roundId?,data?} | 204 |
| GET | /feedback | — | ArchiveFeedback或null |
| POST | /feedback/offer | {taskId} | 首次调查的ArchiveFeedback；已发起过或任务无成功写入时为null |
| POST | /feedback/rating | {rating:1至5整数} | 已保存的ArchiveFeedback |
| POST | /feedback/details | {reasons:FeedbackReason[],comment:string} | 已提交的ArchiveFeedback |

## 关键语义

- `Settings.noteIds` 是本次选择。服务端校验笔记归属与未归档状态并冻结ID快照；运行中新收藏不进入任务。
- Round分开表达 `groups`、`unclassifiedIds`、`hiddenCount`、`skippedIds`、`candidateCount`、`canContinue`，不要从屏幕可见笔记数反推总量。
- `destination:null` 表示主动跳过，不等同于暂时无法匹配。每篇一轮只有一个目的地。调整输入去重，拒绝未知或无权限的目的地、当前不可访问笔记及跨任务ID。
- 开启新建时，新组至少4篇是首次AI建议门槛；人工调整后不得据此解散建议。候选排序按篇数、最近收藏时间，选前5个新组；已有组不占5个名额。
- `apply` 须重新核验可见性与权限、校验公开专辑确认、执行每轮最多5个新专辑限制，同名优先复用。空组不创建。重复请求返回首次真实结果。
- ApplyResult中的 `selectedCount` 是本轮范围数，`archivedCount` 是实际写入成功数，`unclassifiedCount=selectedCount-archivedCount`；返回实际成功IDs。内部保留写入失败原因及分项计数。
- `next` 仅在前轮applied且canContinue为true时允许，使用同任务新roundId。排除已写入与明确跳过项，重复next返回同一下一轮。
- 前端先完成本轮apply并展示结果，再由用户点击「继续归类」触发next，不在预览页预选或自动衔接。提醒同时要求本轮allowNew为true、canContinue为true、实际归档数及未归类数大于0，且当前轮剩余范围中仍有可访问、未归档、未主动跳过的笔记；剩余文案取本轮ApplyResult.unclassifiedCount。关闭允许新建时不显示提醒。next失败保留当前完成页和真实结果，可重试，不回滚已归档数据。
- 取消与apply发生竞争时，后端以真实事务结果为准，不能先向前端承诺取消成功、再继续写入。
- 前端每600ms查询当前轮次，只有一个在途查询，离开生成页忽略旧响应；HTTP请求超时20秒。后端可后续提供轮询建议，但需同步契约。
- 四段AI分析延时文案是前端模拟等待展示，不新增服务端阶段/进度字段。建议提前返回preview时，前端缓存该结果、停止重复查询，等待本轮四段展示结束后再导航；错误或取消不受展示时长限制。展示时间线保存在独立浏览器存储，刷新接续原进度。真实模型的执行节点未来另行接入。
- 事件中的曝光、启动、预览和修正关联taskId/roundId；实际采纳必须由服务端写入结果确认，不能仅依据客户端点击。
- 反馈独立于归档写入。`offer`在用户从最终结果返回收藏页时调用，验证整次task至少一篇实际写入；同一用户仅首次创建，重复调用返回null，关闭未评分也不重复弹窗。多轮中途不发起。Mock按演示情景模拟独立用户，重置清除调查记录。
- `rating`校验1至5整数，并保留首次有效评分；重复提交返回原记录。`details`须已评分，1—3星reason取inaccurate/fragmented/unclear_names/missed_notes/complex_steps/other，4—5星取accurate/clear_grouping/clear_names/existing_match/time_saved/other；按服务端已存星级校验，禁止跨组提交。旧的中性原因ID保留用于读取历史记录。原因去重、comment去首尾空白并限制300字，两者至少填一项。详细反馈重复提交返回首次保存记录。真实后端需按登录用户执行原子校验和持久化；本阶段这些接口仅有HTTP适配约定和Mock实现。

## 后端仍需完成

认证及用户数据隔离、数据导入/获取、AI模型与异步任务、数据库事务、跨客户端幂等与版本冲突、权限校验、调用成本与指标统计。前端没有内置小红书账号采集或收藏读写能力。

## 传输与认证

- 完整路径为 `VITE_API_BASE_URL + 表内路径`，默认例如 `GET /api/library`。路径中的 taskId、roundId 经 URL 编码。
- 当前适配器对所有请求设置 `Content-Type: application/json`，GET 不带请求体；成功返回直接 JSON 对象或数组，不套 `{data: ...}`。
- 返回 `null` 的接口应发送 JSON `null`（HTTP 200），不能发送空 204。标为 204 的 void 接口可发送空响应。
- 请求超时 20 秒，生成页面约每 600ms 查询一次轮次。超时不代表服务端已回滚，apply 重试要复用幂等键。
- 当前 fetch 使用 `credentials: 'same-origin'`，仅同源携带浏览器凭据，未注入 Bearer token。后端需定义登录会话与写接口 CSRF 防护；跨域接入须同步修改前端、CORS 与凭据策略。
- 用户、任务、轮次及专辑的授权均由服务端校验。客户端事件不提交可信 userId/at，服务端补充用户和接收时间。

## 字段说明

字段以 `contracts/archive.ts` 为准；`?` 为可选，其余字段须返回。时间均为 Unix 毫秒时间戳，ID 为字符串，数量为非负整数。

### Library、Profile、Note、Album

| 模型 | 字段 | 类型与含义 |
|---|---|---|
| Library | profile / notes / albums | Profile / Note[] / Album[] |
| Profile | id, name, handle, bio | string，用户标识与展示资料 |
| Profile | lastMaintainedAt | number 或 null，最后维护时间 |
| Profile | reminderSeen | boolean，提醒已读状态 |
| Note | id, title, cover, topic, author | string，笔记 ID、标题、封面 URL、主题、作者 |
| Note | collectedAt / accessible | number 收藏时间 / boolean 当前可访问性 |
| Note | albumIds / kind | string[] 归属专辑 / image 或 video |
| Note | body?, tags?, likes? | string 正文 / string[] 标签 / number 点赞数 |
| Note | sourceCategory?, suggestedTopic? | string，演示种子分类与提示主题；真实模型接入时不可把种子标签当成实际推理结果 |
| Album | id, name, visibility | string、string、private 或 public |

封面在 Mock 种子中为相对路径，随 frontend/public 打包；真实服务应返回访问端可读取的 URL。kind=video 仅为类型标记，当前契约没有视频播放地址。

### Settings、Round、Group

| 模型 | 字段 | 类型与含义 |
|---|---|---|
| Settings | noteIds | string[]，所选未归档笔记快照 |
| Settings | allowNew / rangeLabel | boolean 允许新建 / string 范围展示文案 |
| Round | id, taskId, number | string 轮次 ID、string 任务 ID、number 轮序号（从 1 开始） |
| Round | noteIds / allowNew | 本轮 string[] 范围 / boolean 允许新建 |
| Round | groups | Group[]，本轮可调整归类建议 |
| Round | unclassifiedIds / skippedIds | string[] 未归类项 / string[] 用户明确跳过项 |
| Round | hiddenCount | number，预览隐藏的数量（如关闭新建时的未匹配项） |
| Round | candidateCount | number，候选新分类数，可能大于本轮 5 组上限 |
| Round | canContinue | boolean，按状态与业务规则判断是否还有后续轮次 |
| Round | status | generating / preview / cancelled / error / applied |
| Group | id, name, visibility | 同 Album；新组 ID 是本轮可引用的建议目的地 ID |
| Group | isNew / reason / noteIds | boolean 新组 / string 建议原因 / string[] 笔记 |

adjust.destination 为 groups 中的目标 ID，或 null（跳过）。前端收到 Round 后直接使用该 ID，不根据名字生成 ID。Round 当前没有进度百分比、模型阶段或错误详情字段；错误文案通过 HTTP 错误 message 展示。

### ApplyResult 与反馈

| 模型 | 字段 | 类型与含义 |
|---|---|---|
| ApplyResult | taskId, roundId | string，关联任务和轮次 |
| ApplyResult | selectedCount, archivedCount, unclassifiedCount | number，本轮范围、真实成功、本轮未归类数量 |
| ApplyResult | archivedIds | string[]，实际成功写入的笔记 ID |
| ArchiveFeedback | taskId / offeredAt | string 任务 / number 首次邀请时间 |
| ArchiveFeedback | rating / ratedAt / submittedAt | number 或 null 星级 / number 或 null 评分时间 / number 或 null 详情提交时间 |
| ArchiveFeedback | reasons / comment | FeedbackReason[] / string，未补充时为空数组和空字符串 |

rating 仅允许 1—5 整数；reasons 按星级选取前文列出的 ID。历史原因 accuracy/grouping/naming/missing/experience 仅兼容读取旧记录。comment 去首尾空白、最多 300 字。首次记录和重复请求规则见关键语义。

## 请求与响应示例

示例 ID 和内容用于说明结构，不代表存在对应服务或数据。其余端点的完整请求体见上方端点表。

### 创建任务与查询建议

`POST /api/tasks`：

```json
{"noteIds":["note-1","note-2"],"allowNew":true,"rangeLabel":"全部未归档"}
```

响应（HTTP 200；后端也可使用返回相同结构的 201）：

```json
{
  "id":"round-1","taskId":"task-1","number":1,
  "noteIds":["note-1","note-2"],"allowNew":true,
  "groups":[],"unclassifiedIds":[],"skippedIds":[],
  "hiddenCount":0,"candidateCount":0,"canContinue":false,"status":"generating"
}
```

随后 `GET /api/tasks/task-1/rounds/round-1` 返回最新 Round。生成完成设 status=preview，并返回建议，例如：

```json
{
  "id":"round-1","taskId":"task-1","number":1,
  "noteIds":["note-1","note-2"],"allowNew":true,
  "groups":[{"id":"album-guitar","name":"吉他","visibility":"private","isNew":false,"reason":"匹配已有专辑","noteIds":["note-1","note-2"]}],
  "unclassifiedIds":[],"skippedIds":[],"hiddenCount":0,
  "candidateCount":0,"canContinue":false,"status":"preview"
}
```

### 调整、跳过与确认

`POST /api/tasks/task-1/rounds/round-1/adjust`：

```json
{"noteIds":["note-2"],"destination":null}
```

响应为更新后的完整 Round；此例将 note-2 加入 skippedIds，并从建议目标移除。指定专辑时 destination 使用合法目标 ID。

`POST /api/tasks/task-1/rounds/round-1/apply`：

```json
{"idempotencyKey":"task-1-round-1-apply","confirmedPublicAlbumIds":[]}
```

响应：

```json
{"taskId":"task-1","roundId":"round-1","selectedCount":2,"archivedCount":1,"unclassifiedCount":1,"archivedIds":["note-1"]}
```

公开目标 ID 必须加入 confirmedPublicAlbumIds；服务端再次核验，不能只信任前端勾选状态。相同轮次重复确认应返回首次真实写入结果，不重复建组或归档。

### 反馈与事件

`POST /api/feedback/offer` 请求 `{"taskId":"task-1"}`；无首次调查资格时返回 JSON null。

`POST /api/feedback/rating` 请求 `{"rating":4}`；`POST /api/feedback/details` 请求：

```json
{"reasons":["accurate","time_saved"],"comment":"分类清楚，节省整理时间"}
```

已保存反馈示例：

```json
{"taskId":"task-1","offeredAt":1794499200000,"rating":4,"ratedAt":1794499201000,"submittedAt":1794499202000,"reasons":["accurate","time_saved"],"comment":"分类清楚，节省整理时间"}
```

`POST /api/events` 请求结构为 `{"name":"事件名","taskId":"task-1","roundId":"round-1","data":{}}`，其中关联 ID 与 data 可选。事件名由产品埋点定义，归档成功量必须以服务端事务为准。

## 错误与状态约定（后端实现建议）

当前前端读取错误 message；下列 code 尚无真实服务实现，供后端统一落地。

| HTTP | code 示例 | 场景 |
|---|---|---|
| 400 | INVALID_ARGUMENT | 参数、评分、原因或目标不合法 |
| 401 | UNAUTHENTICATED | 未登录或会话过期 |
| 403 | FORBIDDEN | 笔记、专辑或任务无访问权限 |
| 404 | NOT_FOUND | 任务或轮次不存在 |
| 409 | ROUND_STATE_CONFLICT | 轮次状态、版本冲突或公开确认缺失 |
| 429 | RATE_LIMITED | 请求或模型额度限制 |
| 500 / 503 | INTERNAL_ERROR / SERVICE_UNAVAILABLE | 服务内部错误或模型不可用 |

```json
{"message":"专辑已变为公开，请重新确认后归档","code":"ROUND_STATE_CONFLICT"}
```

部分写入失败时返回 ApplyResult 的真实成功数，未成功项计入 unclassifiedCount；内部逐项原因由后端记录。完整失败、重试与事务策略应在真实后端实现时验证。当前没有文件上传、登录、收藏同步、流式生成或模型密钥配置端点。
