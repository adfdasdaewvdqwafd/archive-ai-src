# 可复制到 RedCoWork 的交接指令

将下列内容和源码 ZIP 一起提供给平台。具体导入与运行能力以平台实际界面为准。

---

请基于附件中的“收藏 AI 归类”项目创建可访问的移动端 Web 演示，保留现有界面和业务规则。

项目为 React 19 + TypeScript + Vite；根目录 package.json 是唯一入口。Node.js 最低 22.12，推荐 24；包管理器为 pnpm 11.25.0。安装：pnpm install --frozen-lockfile；构建：pnpm build；输出目录：dist。优先静态托管。如平台要求 Node 进程，构建后执行 node scripts/serve.mjs，监听 0.0.0.0 并读取 PORT，健康检查为 GET /healthz。

当前使用 VITE_DATA_MODE=mock、VITE_BASE_PATH=./，完整归类和反馈流程在浏览器内运行。frontend/public 中封面是运行资源，须随构建保留。数据保存在访问者本地浏览器。

backend/ 目前保存文案原文件和结构化 JSON。contracts/archive.ts 及 docs/API.md 已定义未来业务接口；真实登录、收藏读写、模型与数据库还需实现。请先发布可运行演示。若需要真实后端，请按现有契约补齐，并核实平台提供的数据库、用户认证、异步任务和密钥配置能力后再切换 http 模式。

请参考 docs/DEPLOYMENT.md 处理构建变量、子路径和资源路径。发布后核验：首页、59 张封面、范围选择、四段等待、预览与调整、公开专辑确认、分轮归档、评分反馈及刷新恢复。

---

如平台要求填构建配置，可直接使用 DEPLOYMENT.md 的配置表。此指令是本项目的交接文本，不是平台官方导入规范。
