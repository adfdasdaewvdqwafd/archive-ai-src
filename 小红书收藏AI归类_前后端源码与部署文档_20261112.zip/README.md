# 收藏 AI 归类：前后端交接源码

整理日期：2026-11-12。移动端 Web 演示，支持范围筛选、归类预览、单条/批量调整、跳过、公开专辑确认、每轮最多 5 个新专辑、继续归类与评分反馈。

当前前端和浏览器 Mock 流程可运行。backend/ 保存文案原文件及结构化配置；真实业务 API、数据库、登录和模型接入待实现。接口文档提供与现有 HTTP 适配器一致的接入契约。

## 快速运行

环境：Node.js 22.12+（推荐 24），pnpm 11.25.0。

```bash
corepack enable
corepack prepare pnpm@11.25.0 --activate
pnpm install --frozen-lockfile
pnpm dev
```

开发访问 http://127.0.0.1:5173/。生产运行：

```bash
pnpm build
pnpm start
```

生产访问 http://127.0.0.1:3000/，健康检查 GET /healthz。首次进入可选择“从未整理过收藏”或“近期未整理收藏”；演示状态在访问者浏览器保存，重置可重新体验。

## 文档入口

- [接口文档](docs/API.md)：14 个业务端点、字段说明、JSON 示例、错误约定与业务约束。
- [部署说明](docs/DEPLOYMENT.md)：RedCoWork 交接、构建配置、静态/Node/Docker 入口、变量与排错。
- [RedCoWork 交接指令](docs/REDCOWORK.md)：可随源码包复制到平台。
- [交付检查](docs/RELEASE_CHECKS.md)：本次验证、打包范围与已知边界。
- [backend 目录说明](backend/README.md)：文案库来源、导入与前端消费方式。

## 包内目录

```text
frontend/                 React 页面、规则、Mock/HTTP 适配器、演示种子与运行图片
backend/                  文案原文件和结构化 JSON（当前没有独立 API 进程）
contracts/archive.ts      前后端共享数据模型与服务契约
scripts/serve.mjs         生产静态服务
scripts/smoke.mjs         生产服务冒烟检查
scripts/import-progress-copies.mjs  文案库重建
 tests/                   既有前端规则与模拟服务测试
 docs/                    接口、部署、平台交接与本次检查说明
package.json 等           依赖锁文件、TypeScript/Vite 配置与环境变量模板
Dockerfile                通用容器示例
```

压缩包采用源码交付，dist/ 由 pnpm build 生成。仅保留本项目的前后端相关文件及构建、验证、说明材料；排除 node_modules、缓存、截图、日志、真实 .env、旧构建和工作区其他项目。59 张演示封面与 fallback.svg 为页面实际资源，随包保留；旧版未引用封面在包外。

## 模式与真实后端接入

默认 VITE_DATA_MODE=mock，完整交互在本地浏览器执行。标题、作者、点赞数等是演示元数据；封面随包提供，视频标记只有封面。

真实服务完成后，在构建环境设 VITE_DATA_MODE=http、VITE_API_BASE_URL=/api 并重新构建。HTTP 错误会直接展示；当前静态服务的 /api/* 明确返回 501。推荐同源网关转发 API，开发代理 API_PROXY_TARGET 仅对本地 Vite 生效。

VITE_* 会公开进入浏览器脚本；模型和数据库密钥放在业务后端。RedCoWork 的具体导入规范与运行环境须以平台界面为准，本次交付未执行平台上线。

## 检查与文案更新

```bash
pnpm check
pnpm test
pnpm build
# 启动生产服务后，在另一终端执行：
node scripts/smoke.mjs http://127.0.0.1:3000/
# 编辑文案原文件后重建 JSON：
pnpm import:progress
```
