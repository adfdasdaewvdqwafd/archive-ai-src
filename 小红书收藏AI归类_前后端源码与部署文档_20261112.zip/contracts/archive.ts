export type Visibility = 'private' | 'public';
export type Scenario = 'main' | 'existing' | 'overflow' | 'five' | 'partial' | 'zero' | 'error' | 'empty' | 'ineligible' | 'no-album' | 'public' | 'correction';
export interface Note {
  id: string; title: string; cover: string; topic: string; collectedAt: number;
  accessible: boolean; albumIds: string[]; kind: 'image' | 'video'; author: string;
  body?: string; tags?: string[]; likes?: number;
  sourceCategory?: string; suggestedTopic?: string;
}
export interface Album { id: string; name: string; visibility: Visibility }
export interface Profile {
  id: string; name: string; handle: string; bio: string;
  lastMaintainedAt: number | null; reminderSeen: boolean;
}
export interface Library { profile: Profile; notes: Note[]; albums: Album[] }
export interface EligibilityConfig { minNotes: number; minUnfiled: number; inactiveDays: number }
export interface Settings { noteIds: string[]; allowNew: boolean; rangeLabel: string }
export interface Group extends Album { isNew: boolean; reason: string; noteIds: string[] }
export interface Round {
  id: string; taskId: string; number: number; noteIds: string[]; allowNew: boolean;
  groups: Group[]; unclassifiedIds: string[]; skippedIds: string[];
  hiddenCount: number; candidateCount: number; canContinue: boolean;
  status: 'generating' | 'preview' | 'cancelled' | 'error' | 'applied';
}
export interface ArchiveTask {
  id: string; snapshotIds: string[]; settings: Settings; rounds: Round[]; skippedIds: string[];
}
export interface ApplyResult {
  taskId: string; roundId: string; selectedCount: number; archivedCount: number;
  unclassifiedCount: number; archivedIds: string[];
}
export interface ApplyRequest { idempotencyKey: string; confirmedPublicAlbumIds: string[] }
export type FeedbackReason =
  | 'inaccurate' | 'fragmented' | 'unclear_names' | 'missed_notes' | 'complex_steps'
  | 'accurate' | 'clear_grouping' | 'clear_names' | 'existing_match' | 'time_saved' | 'other'
  // Previous records retain their original topic IDs.
  | 'accuracy' | 'grouping' | 'naming' | 'missing' | 'experience';
export interface FeedbackDetails { reasons: FeedbackReason[]; comment: string }
export interface ArchiveFeedback extends FeedbackDetails {
  taskId: string; offeredAt: number; rating: number | null; ratedAt: number | null; submittedAt: number | null;
}
export interface ArchiveEvent { name: string; at: number; userId: string; taskId?: string; roundId?: string; data?: Record<string, unknown> }
export interface ArchiveService {
  getLibrary(): Promise<Library>;
  markReminderSeen(): Promise<void>;
  createAlbum(name: string): Promise<Album>;
  startTask(settings: Settings): Promise<Round>;
  getRound(taskId: string, roundId: string): Promise<Round>;
  cancelRound(taskId: string, roundId: string): Promise<void>;
  adjustRound(taskId: string, roundId: string, noteIds: string[], destination: string | null): Promise<Round>;
  applyRound(taskId: string, roundId: string, request: ApplyRequest): Promise<ApplyResult>;
  nextRound(taskId: string, roundId: string): Promise<Round>;
  getFeedback(): Promise<ArchiveFeedback | null>;
  offerFeedback(taskId: string): Promise<ArchiveFeedback | null>;
  rateFeedback(rating: number): Promise<ArchiveFeedback>;
  submitFeedback(details: FeedbackDetails): Promise<ArchiveFeedback>;
  track(event: Omit<ArchiveEvent, 'at' | 'userId'>): Promise<void>;
}
